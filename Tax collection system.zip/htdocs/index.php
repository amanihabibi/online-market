<!DOCTYPE html>
<html>
<head>
<title>Welcome - Business Tax System</title>

<style>
body {
    margin:0;
    font-family: Arial, sans-serif;
    background: linear-gradient(to right, #2c3e50, #27ae60);
    color: #fff;
}

/* Navbar */
.navbar {
    display:flex;
    justify-content:space-between;
    padding:20px 50px;
    background: rgba(0,0,0,0.3);
}

.navbar h2 {
    margin:0;
}

.navbar a {
    color:#fff;
    text-decoration:none;
    margin-left:20px;
    padding:8px 15px;
    border-radius:5px;
    background:#27ae60;
}

.navbar a:hover {
    background:#219150;
}

/* Hero Section */
.hero {
    text-align:center;
    padding:80px 20px;
}

.hero h1 {
    font-size:40px;
    margin-bottom:20px;
}

.hero p {
    font-size:18px;
    margin-bottom:30px;
}

/* Buttons */
.btn {
    padding:12px 25px;
    margin:10px;
    border:none;
    border-radius:5px;
    cursor:pointer;
    font-size:16px;
}

.login-btn {
    background:#3498db;
    color:#fff;
}

.signup-btn {
    background:#f1c40f;
    color:#000;
}

.admin-btn {
    background:#e74c3c;
    color:#fff;
}

.btn:hover {
    opacity:0.9;
}

/* Image Section */
.images {
    display:flex;
    justify-content:center;
    gap:20px;
    padding:40px;
}

.images img {
    width:300px;
    border-radius:10px;
    box-shadow:0 5px 15px rgba(0,0,0,0.3);
}

/* Footer */
.footer {
    text-align:center;
    padding:20px;
    background: rgba(0,0,0,0.3);
}
</style>

</head>

<body>

<!-- Navbar -->
<div class="navbar">
    <h2>Tax Management System</h2>
    <div>
        <a href="main/login.php">Login</a>
        <a href="mock/signup.php">Sign Up</a>
        <a href="admin/login.php">Admin Login</a>
    </div>
</div>

<!-- Hero Section -->
<div class="hero">
    <h1>Welcome to Business Tax Management System</h1>
    <p>
        Manage your business taxes easily, track payments, income, revenue, profits and stay compliant with tax regulations.
        Our system helps you simplify your financial responsibilities in a fast and secure way.
    </p>

    <a href="main/login.php">
        <button class="btn login-btn">Login</button>
    </a>

    <a href="mock/index.php">
        <button class="btn signup-btn">Create Account</button>
    </a>

    <a href="admin/login.php">
        <button class="btn admin-btn">Admin Login</button>
    </a>
</div>

<!-- Images Section -->
<div class="images">
    <img src="https://images.unsplash.com/photo-1554224155-6726b3ff858f" alt="Finance">
    <img src="https://images.unsplash.com/photo-1560472354-b33ff0c44a43" alt="Business">
    <img src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40" alt="Office">
</div>

<!-- Footer -->
<div class="footer">
    <p>© <?php echo date("Y"); ?> Business Tax System | All Rights Reserved</p>
</div>

</body>
</html>