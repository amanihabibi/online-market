<?php
session_start();
include '../connect.php';

if(!isset($_SESSION['admin_id'])){
    header("Location: admin_login.php");
    exit;
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

$currentMonth = date('Y-m');

/* BUSINESS DATA */
$businesses = $conn->query("
SELECT 
b.id,
b.business_name,

COUNT(CASE WHEN DATE_FORMAT(s.sale_date,'%Y-%m') = '$currentMonth' THEN s.id END) AS sales_this_month,

COUNT(CASE WHEN DATE_FORMAT(s.sale_date,'%Y-%m') = DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 1 MONTH),'%Y-%m') THEN s.id END) AS sales_last_month,

SUM(CASE WHEN DATE_FORMAT(s.sale_date,'%Y-%m') = '$currentMonth' THEN (s.total_price - s.total_cost)*0.18 ELSE 0 END) AS tax_this_month

FROM businesses b
LEFT JOIN sales s ON b.id = s.business_id
GROUP BY b.id
");

/* TOP */
$top = $conn->query("
SELECT 
b.business_name,
SUM((s.total_price - s.total_cost)*0.18) AS tax
FROM businesses b
JOIN sales s ON b.id = s.business_id
GROUP BY b.id
ORDER BY tax DESC
LIMIT 5
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Smart AI Risk System</title>

<style>
body{
    margin:0;
    font-family:Segoe UI;
    background:#f4f6f9;
}

/* ================= HEADER ================= */
.header{
    position:fixed;
    top:0;
    left:0;
    width:100%;
    height:65px;
    background:linear-gradient(90deg,#0f172a,#1e293b);
    color:#fff;
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:0 20px;
    z-index:9999;
}

.header .left{font-size:13px;}
.header .center{
    flex:1;
    text-align:center;
    font-size:20px;
    font-weight:800;
}
.header .right{
    display:flex;
    align-items:center;
    gap:10px;
}

.logout-btn{
    background:#ef4444;
    color:#fff;
    padding:8px 14px;
    border-radius:8px;
    text-decoration:none;
}

/* ================= SIDEBAR ================= */
.sidebar{
    width:220px;
    height:100vh;
    position:fixed;
    top:65px;
    left:0;
    background:#2c3e50;
    padding-top:20px;
}

.sidebar a{
    display:block;
    color:#fff;
    padding:14px;
    text-decoration:none;
    transition:0.3s;
}

.sidebar a:hover{
    background:#2980b9;
}

/* ================= MAIN ================= */
.main{
    margin-left:240px;
    padding:90px 20px 40px;
}

/* ================= CARD ================= */
.card{
    background:#fff;
    padding:20px;
    border-radius:12px;
    margin-bottom:20px;
    box-shadow:0 6px 15px rgba(0,0,0,0.08);
}

/* ================= RISK COLORS ================= */
.bad{color:#ef4444;font-weight:bold;}
.mid{color:#f59e0b;font-weight:bold;}
.good{color:#22c55e;font-weight:bold;}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

th,td{
    padding:10px;
    border:1px solid #ddd;
    text-align:center;
}

th{
    background:#1e293b;
    color:#fff;
}

/* ================= FOOTER ================= */
.footer{
    margin-left:220px;
    background:#0f172a;
    color:#cbd5e1;
    padding:30px 20px;
}

.footer-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
    gap:20px;
}

.footer h3{color:#fff;}
.footer a{
    color:#94a3b8;
    text-decoration:none;
    display:block;
    margin:6px 0;
}
.footer a:hover{color:#fff;}

.footer-bottom{
    text-align:center;
    margin-top:20px;
    border-top:1px solid #334155;
    padding-top:10px;
    font-size:13px;
}
</style>
</head>

<body>

<!-- HEADER -->
<div class="header">
    <div class="left">ADMIN PANEL</div>
    <div class="center">SMART BUSINESS RISK DETECTION</div>
    <div class="right">
        <span>Admin</span>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="analytics.php">📊 Analytics</a>
    <a href="reports.php">📋 Reports</a>
    <a href="taxpayers.php">👥 Taxpayers</a>
    
    <a href="settings.php">⚙️ Settings</a>
</div>

<!-- MAIN -->
<div class="main">

<div class="card">
<h2>🧠 AI Risk Analysis</h2>
<p>
✔ Sales activity tracking<br>
✔ Monthly comparison model<br>
✔ Tax behavior detection<br>
✔ Smart seasonal filtering
</p>
</div>

<div class="card">
<h3>📊 Business Risk Report</h3>

<table>
<tr>
<th>Business</th>
<th>Sales This Month</th>
<th>Sales Last Month</th>
<th>Tax This Month</th>
<th>Risk Level</th>
</tr>

<?php while($b = $businesses->fetch_assoc()): 

$sales_now = $b['sales_this_month'];
$sales_last = $b['sales_last_month'];
$tax = $b['tax_this_month'];

if($sales_now == 0){
    $risk = "🔴 HIGH (Inactive)";
    $class = "bad";
} elseif($sales_now < 3 && $tax < 50000){
    $risk = "🟠 MEDIUM";
    $class = "mid";
} elseif($sales_now < $sales_last){
    $risk = "🟡 WATCH";
    $class = "mid";
} else {
    $risk = "🟢 SAFE";
    $class = "good";
}
?>

<tr>
<td><?= $b['business_name'] ?></td>
<td><?= $sales_now ?></td>
<td><?= $sales_last ?></td>
<td><?= number_format($tax) ?></td>
<td class="<?= $class ?>"><?= $risk ?></td>
</tr>

<?php endwhile; ?>
</table>
</div>

<div class="card">
<h3>🏆 Top Performers</h3>

<?php while($t = $top->fetch_assoc()): ?>
<p class="good">✔ <?= $t['business_name'] ?> (<?= number_format($t['tax']) ?> RWF)</p>
<?php endwhile; ?>

</div>

</div>

<!-- FOOTER -->
<div class="footer">

<div class="footer-grid">

<div>
<h3>About</h3>
<p>AI Risk System detects business performance risks and tax anomalies in real time.</p>
</div>

<div>
<h3>Links</h3>
<a href="dashboard.php">Dashboard</a>
<a href="analytics.php">Analytics</a>
<a href="reports.php">Reports</a>
</div>

<div>
<h3>Support</h3>
<a href="#">Help Center</a>
<a href="#">Contact Admin</a>
</div>

</div>

<div class="footer-bottom">
© <?= date("Y") ?> Smart Tax System
</div>

</div>

</body>
</html>