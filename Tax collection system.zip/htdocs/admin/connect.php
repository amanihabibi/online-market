<?php
// Database configuration
$servername = "sql213.infinityfree.com";      // usually localhost
$username = "if0_41500573";             // your MySQL username
$password = "moniquefra123";                 // your MySQL password
$database = "if0_41500573_mock_rra_system"; // database we created

// Create connection using MySQLi
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Optional: set charset to avoid encoding issues
$conn->set_charset("utf8");

?>