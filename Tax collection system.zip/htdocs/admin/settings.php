<?php
session_start();
include '../connect.php';

if(!isset($_SESSION['admin_id'])){
    header("Location: admin_login.php");
    exit;
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

$admin_id = $_SESSION['admin_id'];

/* ADMIN DATA */
$admin = $conn->query("SELECT * FROM admins WHERE id=$admin_id")->fetch_assoc();

/* UPDATE PROFILE */
if(isset($_POST['update_profile'])){

    $name = $_POST['name'];
    $email = $_POST['email'];

    $stmt = $conn->prepare("UPDATE admins SET full_name=?, username=? WHERE id=?");
    $stmt->bind_param("ssi", $name, $email, $admin_id);
    $stmt->execute();

    echo "<script>alert('✅ Profile updated successfully');</script>";
}

/* CHANGE PASSWORD */
if(isset($_POST['change_password'])){

    $old = $_POST['old_password'];
    $new = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];

    if(!password_verify($old, $admin['password'])){
        echo "<script>alert('❌ Old password is incorrect');</script>";
    }
    elseif($new != $confirm){
        echo "<script>alert('❌ Passwords do not match');</script>";
    }
    else{
        $hashed = password_hash($new, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("UPDATE admins SET password=? WHERE id=?");
        $stmt->bind_param("si", $hashed, $admin_id);
        $stmt->execute();

        echo "<script>alert('✅ Password changed successfully');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Settings</title>

<style>
body{
    margin:0;
    font-family:Arial;
    background:#f4f6f9;
}

/* ================= HEADER ================= */
.header{
    background:linear-gradient(90deg,#2c3e50,#1a252f);
    color:#fff;
    padding:15px 20px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    position:fixed;
    width:100%;
    top:0;
    z-index:1000;
}

.header h2{
    margin:0;
    font-size:20px;
    text-align:center;
    flex:1;
}

.logout-btn{
    background:#e74c3c;
    color:#fff;
    padding:8px 14px;
    border-radius:20px;
    text-decoration:none;
    font-size:14px;
}

.logout-btn:hover{
    background:#c0392b;
}

/* ================= SIDEBAR ================= */
.sidebar{
    width:240px;
    height:100vh;
    background:#2c3e50;
    position:fixed;
    top:60px;
    left:0;
    padding-top:20px;
}

.sidebar a{
    display:block;
    color:#fff;
    padding:12px 20px;
    text-decoration:none;
}

.sidebar a:hover{
    background:#2980b9;
}

/* ================= MAIN ================= */
.main{
    margin-left:240px;
    padding:90px 20px 80px;
}

/* CARD */
.card{
    background:#fff;
    padding:20px;
    border-radius:10px;
    margin-bottom:20px;
    box-shadow:0 3px 10px rgba(0,0,0,0.1);
}

/* INPUT */
input{
    width:100%;
    padding:10px;
    margin:8px 0;
    border:1px solid #ccc;
    border-radius:5px;
}

button{
    padding:10px 15px;
    background:#27ae60;
    color:#fff;
    border:none;
    border-radius:5px;
    cursor:pointer;
}

button:hover{
    background:#219150;
}

/* ================= FOOTER ================= */
.footer{
    margin-left:240px;
    background:#1a252f;
    color:#fff;
    padding:25px;
}

.footer-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
    gap:20px;
}

.footer h4{
    color:#1abc9c;
    margin-bottom:10px;
}

.footer a{
    color:#bdc3c7;
    text-decoration:none;
    display:block;
    margin:5px 0;
}

.footer a:hover{
    color:#1abc9c;
}

.footer-bottom{
    text-align:center;
    margin-top:15px;
    border-top:1px solid #34495e;
    padding-top:10px;
    font-size:13px;
}
</style>
</head>

<body>

<!-- HEADER -->
<div class="header">
    <div></div>
    <h2>⚙ Admin Settings Panel</h2>
    
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="analytics.php">📊 Analytics</a>
    <a href="reports.php">📋 Reports</a>
    <a href="taxpayers.php">👥 Taxpayers</a>
   
    <a href="settings.php">⚙️ Settings</a>
    <a href="logout.php" style="background:red;">🚪 Logout</a>
</div>

<!-- MAIN -->
<div class="main">

<!-- PROFILE -->
<div class="card">
<h2>👤 Profile Settings</h2>

<form method="POST">

<label>Name</label>
<input type="text" name="name" value="<?= $admin['full_name'] ?>" required>

<label>Username</label>
<input type="text" name="email" value="<?= $admin['username'] ?>" required>

<button type="submit" name="update_profile">💾 Update Profile</button>

</form>
</div>

<!-- PASSWORD -->
<div class="card">
<h2>🔐 Change Password</h2>

<form method="POST">

<label>Old Password</label>
<input type="password" name="old_password" required>

<label>New Password</label>
<input type="password" name="new_password" required>

<label>Confirm Password</label>
<input type="password" name="confirm_password" required>

<button type="submit" name="change_password">🔒 Change Password</button>

</form>

</div>

</div>

<!-- FOOTER -->
<div class="footer">

<div class="footer-grid">

    <div>
        <h4>About System</h4>
        <p>Admin control panel for managing users, businesses, taxes, and system settings in real-time.</p>
    </div>

    <div>
        <h4>Quick Links</h4>
        <a href="dashboard.php">Dashboard</a>
        <a href="analytics.php">Analytics</a>
        <a href="reports.php">Reports</a>
    </div>

    <div>
        <h4>Support</h4>
        <p>📍 Kigali, Rwanda</p>
        <p>📧 admin@system.com</p>
    </div>

</div>

<div class="footer-bottom">
    © <?= date("Y") ?> Admin System | All Rights Reserved
</div>

</div>

</body>
</html>