<?php
session_start();
include '../connect.php';

if(!isset($_SESSION['admin_id'])){
    header("Location: admin_login.php");
    exit;
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

/* =========================
   GLOBAL TOTAL (NO DOUBLE COUNTING)
========================= */
$global = $conn->query("
SELECT 
    SUM(revenue) AS total_revenue,
    SUM(cost) AS total_cost,
    SUM(profit) AS total_profit,
    SUM(tax) AS total_tax
FROM (
    SELECT 
        b.id,
        COALESCE(SUM(s.total_price),0) AS revenue,
        COALESCE(SUM(s.total_cost),0) AS cost,
        (COALESCE(SUM(s.total_price),0) - COALESCE(SUM(s.total_cost),0)) AS profit,
        (COALESCE(SUM(s.total_price),0) - COALESCE(SUM(s.total_cost),0)) * 0.18 AS tax
    FROM businesses b
    LEFT JOIN sales s ON b.id = s.business_id
    GROUP BY b.id
) x
")->fetch_assoc();

$total_revenue = $global['total_revenue'] ?? 0;
$total_cost = $global['total_cost'] ?? 0;
$total_profit = $global['total_profit'] ?? 0;
$total_tax = $global['total_tax'] ?? 0;


/* =========================
   MONTHLY TAX (TOTAL SYSTEM)
========================= */
$monthly = $conn->query("
SELECT 
    month,
    SUM(tax) AS tax
FROM (
    SELECT 
        b.id,
        DATE_FORMAT(s.sale_date,'%Y-%m') AS month,
        (COALESCE(SUM(s.total_price),0) - COALESCE(SUM(s.total_cost),0)) * 0.18 AS tax
    FROM businesses b
    LEFT JOIN sales s ON b.id = s.business_id
    GROUP BY b.id, month
) x
GROUP BY month
ORDER BY month ASC
");

$months = [];
$taxData = [];

while($r = $monthly->fetch_assoc()){
    $months[] = $r['month'];
    $taxData[] = $r['tax'];
}


/* =========================
   BUSINESS TAX (TOP 10)
========================= */
$business = $conn->query("
SELECT 
    b.business_name,
    COALESCE(SUM(s.total_price - s.total_cost),0) * 0.18 AS tax
FROM businesses b
LEFT JOIN sales s ON b.id = s.business_id
GROUP BY b.id
ORDER BY tax DESC
LIMIT 10
");

$bizNames = [];
$bizTax = [];

while($b = $business->fetch_assoc()){
    $bizNames[] = $b['business_name'];
    $bizTax[] = $b['tax'];
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Tax Report</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
body{
    margin:0;
    font-family:Segoe UI;
    background:#f4f6f9;
}

/* HEADER */
.header{
    position:fixed;
    top:0;
    left:0;
    width:100%;
    height:60px;
    background:#0f172a;
    color:#fff;
    display:flex;
    justify-content:center;
    align-items:center;
    font-weight:bold;
}

.logout{
    position:absolute;
    right:20px;
    background:red;
    padding:6px 12px;
    border-radius:6px;
    color:#fff;
    text-decoration:none;
}

/* SIDEBAR */
.sidebar{
    width:220px;
    height:100vh;
    position:fixed;
    top:60px;
    left:0;
    background:#34495e;
    padding-top:10px;
}

.sidebar a{
    display:block;
    color:#fff;
    padding:10px;
    text-decoration:none;
}

/* MAIN */
.main{
    margin-left:220px;
    padding:80px 15px;
}

/* CARD */
.card{
    background:#fff;
    padding:15px;
    border-radius:8px;
    margin-bottom:15px;
}

/* FOOTER */
.footer{
    margin-left:220px;
    background:#0f172a;
    color:#cbd5e1;
    padding:20px;
    text-align:center;
    font-size:13px;
}
</style>
</head>

<body>

<!-- HEADER -->
<div class="header">
    📊 TAX REPORT SYSTEM
    <a class="logout" href="logout.php">Logout</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="analytics.php">📊 Analytics</a>
    <a href="taxpayers.php">📋 Taxpayers</a>
    <a href="reports.php">📋 Reports</a>
    <a href="taxpayers.php">👥 Taxpayers</a>
    <a href="settings.php">⚙️ Settings</a>
</div>

<!-- MAIN -->
<div class="main">

<div class="card">
<h3>📊 TOTAL TAX COLLECTED</h3>
<p><b>Revenue:</b> <?= number_format($total_revenue) ?></p>
<p><b>Cost:</b> <?= number_format($total_cost) ?></p>
<p><b>Profit:</b> <?= number_format($total_profit) ?></p>
<p><b>Tax:</b> <?= number_format($total_tax) ?></p>
</div>

<div class="card">
<h3>📈 Monthly Total Tax</h3>
<canvas id="monthlyChart"></canvas>
</div>

<div class="card">
<h3>🏢 Tax Per Business (Top 10)</h3>
<canvas id="bizChart"></canvas>
</div>

</div>

<!-- FOOTER -->
<div class="footer">
© <?= date("Y") ?> Smart Tax System | All Rights Reserved
</div>

<script>
new Chart(document.getElementById('monthlyChart'),{
type:'line',
data:{
labels:<?= json_encode($months) ?>,
datasets:[{
label:'Total Tax Collected',
data:<?= json_encode($taxData) ?>,
borderColor:'orange',
fill:false
}]
}
});

new Chart(document.getElementById('bizChart'),{
type:'bar',
data:{
labels:<?= json_encode($bizNames) ?>,
datasets:[{
label:'Tax per Business',
data:<?= json_encode($bizTax) ?>,
backgroundColor:'green'
}]
}
});
</script>

</body>
</html>