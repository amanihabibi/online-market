<?php
session_start();
include '../connect.php';

$error = '';

if(isset($_POST['login'])){
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Fetch admin
    $stmt = $conn->prepare("SELECT * FROM admins WHERE username=? LIMIT 1");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $admin = $stmt->get_result()->fetch_assoc();

    if($admin && password_verify($password, $admin['password'])){
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_name'] = $admin['full_name'];
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Invalid username or password";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Login - Tax System</title>
<style>
body { font-family: Arial; background:#2c3e50; color:#fff; display:flex; justify-content:center; align-items:center; height:100vh; margin:0; }
.login-box { background:#34495e; padding:40px; border-radius:10px; width:350px; }
.login-box h2 { text-align:center; margin-bottom:30px; }
.login-box input { width:100%; padding:10px; margin:10px 0; border:none; border-radius:5px; }
.login-box button { width:100%; padding:10px; background:#e74c3c; border:none; border-radius:5px; color:#fff; font-size:16px; cursor:pointer; }
.login-box button:hover { opacity:0.9; }
.error { background:#c0392b; padding:10px; border-radius:5px; text-align:center; margin-bottom:10px; }
</style>
</head>
<body>

<div class="login-box">
    <h2>Admin Login</h2>

    <?php if($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit" name="login">Login</button>
    </form>
</div>

</body>
</html>