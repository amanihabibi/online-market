<?php
session_start();
include '../connect.php';

$error = '';
$success = '';

if(isset($_POST['signup'])){
    $full_name = trim($_POST['full_name']);
    $username  = trim($_POST['username']);
    $password  = $_POST['password'];
    $confirm   = $_POST['confirm_password'];

    if($password !== $confirm){
        $error = "Passwords do not match.";
    } else {
        // Check if username exists
        $stmt = $conn->prepare("SELECT id FROM admins WHERE username=?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        if($stmt->get_result()->num_rows > 0){
            $error = "Username already exists.";
        } else {
            // Insert new admin
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $insert = $conn->prepare("INSERT INTO admins (full_name, username, password) VALUES (?,?,?)");
            $insert->bind_param("sss", $full_name, $username, $hash);
            if($insert->execute()){
                $success = "Admin account created successfully. <a href='admin_login.php'>Login now</a>.";
            } else {
                $error = "Failed to create account. Try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Signup - Tax System</title>
<style>
body { font-family: Arial; background:#2c3e50; color:#fff; display:flex; justify-content:center; align-items:center; height:100vh; margin:0; }
.signup-box { background:#34495e; padding:40px; border-radius:10px; width:400px; }
.signup-box h2 { text-align:center; margin-bottom:30px; }
.signup-box input { width:100%; padding:10px; margin:10px 0; border:none; border-radius:5px; }
.signup-box button { width:100%; padding:10px; background:#27ae60; border:none; border-radius:5px; color:#fff; font-size:16px; cursor:pointer; }
.signup-box button:hover { opacity:0.9; }
.error { background:#c0392b; padding:10px; border-radius:5px; text-align:center; margin-bottom:10px; }
.success { background:#27ae60; padding:10px; border-radius:5px; text-align:center; margin-bottom:10px; }
</style>
</head>
<body>

<div class="signup-box">
    <h2>Admin Signup</h2>

    <?php if($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if($success): ?>
        <div class="success"><?= $success ?></div>
    <?php else: ?>
    <form method="POST">
        <input type="text" name="full_name" placeholder="Full Name" required>
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="password" name="confirm_password" placeholder="Confirm Password" required>
        <button type="submit" name="signup">Create Admin</button>
    </form>
    <p style="text-align:center;margin-top:10px;">Already have an account? <a href="admin_login.php" style="color:#f1c40f;">Login</a></p>
    <?php endif; ?>
</div>

</body>
</html>