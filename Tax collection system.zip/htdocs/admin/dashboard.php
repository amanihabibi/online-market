<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include '../connect.php';

if(!isset($_SESSION['admin_id'])){
    header("Location: admin_login.php");
    exit;
}

/* =========================
   PER BUSINESS FINANCIAL MODEL (SOURCE OF TRUTH)
========================= */
$global = $conn->query("
SELECT 
    SUM(revenue) AS total_revenue,
    SUM(cost) AS total_cost,
    SUM(profit) AS total_profit,
    SUM(tax) AS total_tax
FROM (
    SELECT 
        b.id,

        COALESCE(SUM(s.total_price),0) AS revenue,
        COALESCE(SUM(s.total_cost),0) AS cost,

        (COALESCE(SUM(s.total_price),0) - COALESCE(SUM(s.total_cost),0)) AS profit,

        (COALESCE(SUM(s.total_price),0) - COALESCE(SUM(s.total_cost),0)) * 0.18 AS tax

    FROM businesses b
    LEFT JOIN sales s ON b.id = s.business_id
    GROUP BY b.id
) AS x
")->fetch_assoc();

$total_revenue = $global['total_revenue'] ?? 0;
$total_cost = $global['total_cost'] ?? 0;
$total_profit = $global['total_profit'] ?? 0;
$total_tax = $global['total_tax'] ?? 0;

/* =========================
   USERS & BUSINESSES
========================= */
$users = $conn->query("SELECT COUNT(*) as total_users FROM taxpayers")->fetch_assoc();
$total_users = $users['total_users'] ?? 0;

$biz = $conn->query("SELECT COUNT(*) as total_biz FROM businesses")->fetch_assoc();
$total_biz = $biz['total_biz'] ?? 0;

/* =========================
   CHART DATA
========================= */
$data = $conn->query("
SELECT 
    DATE(sale_date) as d,
    SUM(total_price) as revenue,
    SUM((total_price - total_cost) * 0.18) as tax
FROM sales
WHERE sale_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
GROUP BY DATE(sale_date)
ORDER BY d ASC
");

$dates=[];$rev=[];$taxes=[];
while($r=$data->fetch_assoc()){
    $dates[]=$r['d'];
    $rev[]=$r['revenue'];
    $taxes[]=$r['tax'];
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Smart Tax Admin Dashboard</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
body{
    margin:0;
    font-family:Segoe UI;
    background:#f4f6f9;
}

/* HEADER */
.header{
    position:fixed;
    top:0;
    left:0;
    width:100%;
    height:65px;
    background:linear-gradient(90deg,#0f172a,#1e293b);
    color:#fff;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:20px;
    font-weight:800;
    z-index:9999;
}

.logout-btn{
    position:absolute;
    right:20px;
    background:#ef4444;
    color:#fff;
    padding:8px 14px;
    border-radius:8px;
    text-decoration:none;
}

/* SIDEBAR */
.sidebar{
    width:220px;
    height:100vh;
    position:fixed;
    top:65px;
    left:0;
    background:#34495e;
    padding-top:20px;
}

.sidebar a{
    display:block;
    color:#fff;
    padding:14px;
    text-decoration:none;
    border-left:4px solid transparent;
}

.sidebar a:hover{
    background:#2c3e50;
    border-left:4px solid #1abc9c;
}

/* MAIN */
.main{
    margin-left:240px;
    padding:90px 20px 40px;
}

/* CARDS */
.cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
    gap:15px;
}

.card{
    background:#fff;
    padding:20px;
    border-radius:12px;
    text-align:center;
    box-shadow:0 6px 15px rgba(0,0,0,0.08);
}

.card h4{color:#64748b;margin:0;}
.card p{font-size:22px;font-weight:bold;margin-top:10px;}

/* CHART */
.chart-box{
    background:#fff;
    padding:20px;
    border-radius:12px;
    margin-top:20px;
    box-shadow:0 6px 15px rgba(0,0,0,0.08);
}

/* FOOTER */
.footer{
    margin-left:220px;
    background:#0f172a;
    color:#cbd5e1;
    padding:30px 20px;
    margin-top:30px;
}

.footer-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
    gap:20px;
}

.footer h3{color:#fff;}
.footer a{color:#94a3b8;text-decoration:none;display:block;margin:6px 0;}
.footer a:hover{color:#fff;}

.footer-bottom{
    text-align:center;
    margin-top:20px;
    border-top:1px solid #334155;
    padding-top:10px;
    font-size:13px;
}
</style>
</head>

<body>

<!-- HEADER -->
<div class="header">
    SMART TAX ADMIN DASHBOARD
    <a href="logout.php" class="logout-btn">Logout</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="analytics.php">📊 Analytics</a>
    <a href="reports.php">📋 Reports</a>
    <a href="taxpayers.php">👥 Taxpayers</a>
    <a href="settings.php">⚙️ Settings</a>
</div>

<!-- MAIN -->
<div class="main">

<h2>📊 System Overview</h2>

<div class="cards">
    <div class="card"><h4>Users</h4><p><?= $total_users ?></p></div>
    <div class="card"><h4>Businesses</h4><p><?= $total_biz ?></p></div>

    <div class="card"><h4>Total Revenue</h4><p><?= number_format($total_revenue) ?></p></div>
    <div class="card"><h4>Total Cost</h4><p><?= number_format($total_cost) ?></p></div>

    <div class="card"><h4>Total Profit</h4><p><?= number_format($total_profit) ?></p></div>

    <div class="card" style="background:#0f172a;color:white;">
        <h4 style="color:white;">Total Tax Collected</h4>
        <p><?= number_format($total_tax) ?></p>
    </div>
</div>

<div class="chart-box">
<h3>📈 Revenue vs Tax (30 Days)</h3>
<canvas id="chart"></canvas>
</div>

<script>
new Chart(document.getElementById('chart'),{
type:'line',
data:{
labels:<?= json_encode($dates) ?>,
datasets:[
{label:'Revenue',data:<?= json_encode($rev) ?>,borderColor:'green',fill:false},
{label:'Tax',data:<?= json_encode($taxes) ?>,borderColor:'orange',fill:false}
]
}
});
</script>

</div>

<!-- FOOTER -->
<div class="footer">

<div class="footer-grid">

<div>
<h3>About</h3>
<p>Smart Tax System calculates tax per business and aggregates real financial performance.</p>
</div>

<div>
<h3>Links</h3>
<a href="dashboard.php">Dashboard</a>
<a href="reports.php">Reports</a>
<a href="analytics.php">Analytics</a>
<a href="taxpayers.php">Taxpayers</a>
</div>

<div>
<h3>Support</h3>
<a href="#">Help Center</a>
<a href="#">Contact IT</a>
</div>

</div>

<div class="footer-bottom">
© <?= date("Y") ?> Smart Tax System | All Rights Reserved
</div>

</div>

</body>
</html>