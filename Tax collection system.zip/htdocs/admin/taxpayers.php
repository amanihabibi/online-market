<?php
session_start();
include '../connect.php';

if(!isset($_SESSION['admin_id'])){
    header("Location: admin_login.php");
    exit;
}

// SEARCH INPUT
$search = $_GET['search'] ?? '';

// PAGINATION
$limit = 10;
$page = isset($_GET['page']) ? (int)$page : 1;
$offset = ($page - 1) * $limit;

// WHERE
$where = "WHERE 1=1";

if(!empty($search)){
    $search = $conn->real_escape_string($search);

    $where .= " AND (
        full_name LIKE '%$search%' 
        OR email LIKE '%$search%' 
        OR phone LIKE '%$search%'
    )";
}

// DATA
$sql = "SELECT * FROM taxpayers $where ORDER BY id DESC LIMIT $limit OFFSET $offset";
$result = $conn->query($sql);

// COUNT
$count_sql = "SELECT COUNT(*) as total FROM taxpayers $where";
$total_rows = $conn->query($count_sql)->fetch_assoc()['total'];
$total_pages = ceil($total_rows / $limit);
?>

<!DOCTYPE html>
<html>
<head>
<title>Taxpayers Registry</title>

<style>
body{
    margin:0;
    font-family:Segoe UI, Arial;
    background:#f4f6f9;
}

/* SIDEBAR */
.sidebar{
    width:240px;
    height:100vh;
    background:#2c3e50;
    position:fixed;
    top:0;
    left:0;
    padding-top:20px;
}

.sidebar h3{
    color:#fff;
    text-align:center;
    margin-bottom:15px;
}

.sidebar a{
    display:block;
    color:#fff;
    padding:12px 18px;
    text-decoration:none;
}

.sidebar a:hover{
    background:#2980b9;
}

/* HEADER */
.header{
    position:fixed;
    left:240px;
    right:0;
    top:0;
    height:65px;
    background:linear-gradient(90deg,#1f3b57,#2c3e50);
    color:#fff;
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:20px;
    font-weight:bold;
    z-index:1000;
}

.logout{
    position:absolute;
    right:20px;
    background:red;
    padding:8px 14px;
    border-radius:20px;
    color:#fff;
    text-decoration:none;
    font-size:13px;
}

/* MAIN */
.main{
    margin-left:240px;
    padding:90px 20px 60px;
}

/* CARD */
.card{
    background:#fff;
    padding:15px;
    border-radius:8px;
    margin-bottom:15px;
    box-shadow:0 2px 8px rgba(0,0,0,0.08);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

th,td{
    padding:12px;
    border:1px solid #ddd;
    text-align:center;
}

th{
    background:#2c3e50;
    color:#fff;
}

/* FORM */
form{
    display:flex;
    gap:10px;
    flex-wrap:wrap;
}

input{
    padding:10px;
    border:1px solid #ccc;
    border-radius:5px;
}

button{
    padding:10px 15px;
    background:#2980b9;
    color:#fff;
    border:none;
    border-radius:5px;
}

/* PAGINATION */
.pagination a{
    padding:8px 12px;
    margin:2px;
    background:#2980b9;
    color:#fff;
    text-decoration:none;
    border-radius:5px;
}

/* ================= YOUR ORIGINAL FOOTER ================= */
.smart-footer{
    background:#1a252f;
    color:#ecf0f1;
    padding:30px 25px 10px;
    margin-left:240px;
}

.footer-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:20px;
}

.footer-col h3{
    margin-bottom:10px;
    color:#1abc9c;
}

.footer-col p{
    font-size:14px;
    line-height:1.6;
}

.footer-links a{
    display:block;
    color:#bdc3c7;
    text-decoration:none;
    margin:6px 0;
    font-size:14px;
    transition:0.3s;
}

.footer-links a:hover{
    color:#1abc9c;
    padding-left:5px;
}

.footer-bottom{
    border-top:1px solid #34495e;
    margin-top:20px;
    padding-top:10px;
    text-align:center;
    font-size:13px;
    color:#aaa;
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h3>Admin Panel</h3>

    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="analytics.php">📊 Analytics</a>
    <a href="reports.php">📋 Reports</a>
    <a href="taxpayers.php">👥 Taxpayers</a>
    <a href="settings.php">⚙️ Settings</a>
    <a href="logout.php" style="background:#e74c3c;">🚪 Logout</a>
</div>

<!-- HEADER -->
<div class="header">
    👥 Taxpayers Registry
    <a class="logout" href="logout.php">Logout</a>
</div>

<!-- MAIN -->
<div class="main">

<div class="card">
<form method="GET">

    <input type="text" name="search"
        placeholder="Search name, email, phone..."
        value="<?= htmlspecialchars($search) ?>">

    <button type="submit">🔍 Search</button>

    <a href="taxpayers.php"
       style="padding:10px;background:red;color:#fff;text-decoration:none;border-radius:5px;">
        Reset
    </a>

</form>
</div>

<div class="card">
<table>
<tr>
    <th>ID</th>
    <th>Full Name</th>
    <th>Email</th>
    <th>Phone</th>
</tr>

<?php while($row = $result->fetch_assoc()): ?>
<tr>
    <td><?= $row['id'] ?></td>
    <td><?= htmlspecialchars($row['full_name']) ?></td>
    <td><?= htmlspecialchars($row['email']) ?></td>
    <td><?= htmlspecialchars($row['phone'] ?? 'N/A') ?></td>
</tr>
<?php endwhile; ?>

</table>
</div>

<div class="card pagination">
<?php for($i=1;$i<=$total_pages;$i++): ?>
    <a href="?page=<?= $i ?>&search=<?= urlencode($search) ?>">
        <?= $i ?>
    </a>
<?php endfor; ?>
</div>

</div>

<!-- FOOTER (YOUR ORIGINAL STYLE) -->
<div class="smart-footer">

    <div class="footer-grid">

        <div class="footer-col">
            <h3>About</h3>
            <p>
                Smart Tax System helps businesses manage sales, calculate tax,
                and track deadlines easily. Built for efficiency and transparency.
            </p>
        </div>

        <div class="footer-col footer-links">
            <h3>Quick Links</h3>
            <a href="dashboard.php">Dashboard</a>
            <a href="analytics.php">Analytics</a>
            <a href="reports.php">Reports</a>
            <a href="taxpayers.php">Taxpayers</a>
            <a href="settings.php">Settings</a>
        </div>

        <div class="footer-col">
            <h3>Contact</h3>
            <p>📍 Kigali, Rwanda</p>
            <p>📞 +250 7XX XXX XXX</p>
            <p>📧 support@smarttax.com</p>
        </div>

    </div>

    <div class="footer-bottom">
        © <?= date("Y") ?> Smart Tax System | All Rights Reserved
    </div>

</div>

</body>
</html>