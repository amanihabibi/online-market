<?php
session_start();
include '../connect.php';

// Check login
if(!isset($_SESSION['taxpayer_id'])){
    header("Location: login.php");
    exit;
}

// Get taxpayer id and tax id
$taxpayer_id = $_SESSION['taxpayer_id'];
$tax_id = $_POST['tax_id'] ?? 0;

// Check that tax belongs to user and is unpaid
$stmt = $conn->prepare("SELECT t.*, u.business_type FROM taxes t JOIN taxpayers u ON t.taxpayer_id=u.id WHERE t.id=? AND t.taxpayer_id=? AND t.paid=0");
$stmt->bind_param("ii", $tax_id, $taxpayer_id);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows == 0){
    $_SESSION['error'] = "Tax not found or already paid!";
    header("Location: user_dashboard.php");
    exit;
}

$tax = $result->fetch_assoc();
$business_type = $tax['business_type'];

// Mark tax as paid
$stmt = $conn->prepare("UPDATE taxes SET paid=1, paid_date=CURDATE() WHERE id=? AND taxpayer_id=?");
$stmt->bind_param("ii", $tax_id, $taxpayer_id);
$stmt->execute();

// Schedule next tax for 3 months later
$next_tax_type = $tax['tax_type'];
$next_amount = 0;
$next_due_date = date('Y-m-d', strtotime("+3 months"));

// Amount based on business type
switch($business_type){
    case "Shop": $next_amount = 150000; break;
    case "Restaurant": $next_amount = 200000; break;
    case "Mobile Money Agent": $next_amount = 50000; break;
    default: $next_amount = 100000; break;
}

// Insert next scheduled tax
$stmt = $conn->prepare("INSERT INTO taxes (taxpayer_id, tax_type, assigned_amount, due_date) VALUES (?, ?, ?, ?)");
$stmt->bind_param("isds", $taxpayer_id, $next_tax_type, $next_amount, $next_due_date);
$stmt->execute();

$_SESSION['success'] = "Tax declared successfully. Next tax scheduled on $next_due_date.";
header("Location:dashboard.php");
exit;
?>