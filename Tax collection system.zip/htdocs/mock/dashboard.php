<?php
session_start();
include '../connect.php';

if(!isset($_SESSION['taxpayer_id'])){
    header("Location: login.php");
    exit;
}

$taxpayer_id = $_SESSION['taxpayer_id'];

/* GET BUSINESS */
$business = $conn->query("
SELECT * FROM businesses 
WHERE taxpayer_id=$taxpayer_id 
LIMIT 1
")->fetch_assoc();

$business_id = $business['id'];
$tax_due = $business['tax'];
$next_tax_date = $business['next_tax_date'];

/* GET LAST PAYMENT (ONLY FOR CURRENT TAX PERIOD) */
$last_payment = $conn->query("
SELECT * FROM payments 
WHERE business_id=$business_id 
AND payment_date >= '$next_tax_date'
ORDER BY id DESC 
LIMIT 1
")->fetch_assoc();

/* HISTORY */
$history = $conn->query("
SELECT * FROM payments 
WHERE business_id=$business_id 
ORDER BY id DESC
");

/* PAY NOW */
if(isset($_POST['pay'])){

    $conn->query("
    INSERT INTO payments (business_id, amount, status, payment_date)
    VALUES ($business_id, $tax_due, 'paid', CURDATE())
    ");

    echo "<script>alert('✅ Payment Successful'); window.location='user_dashboard.php';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Mock RRA - User Dashboard</title>

<style>
body{margin:0;font-family:Arial;background:#f4f6f9;}

.sidebar{
width:240px;
height:100vh;
background:#2c3e50;
position:fixed;
padding-top:20px;
}

.sidebar a{
display:block;
color:#fff;
padding:12px 20px;
text-decoration:none;
}

.sidebar a:hover{background:#2980b9;}

.topbar{
margin-left:240px;
background:#fff;
padding:15px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}

.main{margin-left:240px;padding:20px;}

.card{
background:#fff;
padding:20px;
border-radius:10px;
margin-bottom:20px;
box-shadow:0 3px 10px rgba(0,0,0,0.1);
}

button{
background:#27ae60;
color:#fff;
border:none;
padding:10px 15px;
border-radius:5px;
cursor:pointer;
}

button:hover{background:#219150;}

.good{color:green;font-weight:bold;}
.bad{color:red;font-weight:bold;}
.mid{color:orange;font-weight:bold;}

table{
width:100%;
border-collapse:collapse;
}

th,td{
border:1px solid #ddd;
padding:10px;
}

th{
background:#34495e;
color:#fff;
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h3 style="color:#fff;text-align:center;">🏛 RRA MOCK</h3>
    <a href="user_dashboard.php">🏠 Dashboard</a>
    <a href="../main/dashboard.php">🔙 Main System</a>
    <a href="logout.php">🚪 Logout</a>
</div>

<!-- TOPBAR -->
<div class="topbar">
    <h3>Mock RRA - Taxpayer Panel</h3>
</div>

<!-- MAIN -->
<div class="main">

<!-- TAX INFO -->
<div class="card">
<h2>💰 Tax Summary</h2>

<p>Fixed Tax: <b><?= number_format($tax_due) ?> RWF</b></p>
<p>Next Tax Date: <b><?= $next_tax_date ?></b></p>

<?php if($last_payment): ?>
    <p class="good">✅ Tax Paid for Current Period</p>
<?php else: ?>
    <p class="bad">❌ Not Paid for Current Period</p>
<?php endif; ?>

</div>

<!-- PAY NOW -->
<div class="card">
<h2>💳 Pay Tax</h2>

<?php if($last_payment): ?>
    <p class="good">✔ Already Paid for this period</p>
<?php else: ?>
<form method="POST">
<button type="submit" name="pay">
Pay Now (<?= number_format($tax_due) ?> RWF)
</button>
</form>
<?php endif; ?>

</div>

<!-- HISTORY -->
<div class="card">
<h2>📋 Payment History</h2>

<table>
<tr>
<th>Amount</th>
<th>Status</th>
<th>Date</th>
</tr>

<?php while($p = $history->fetch_assoc()): ?>
<tr>
<td><?= number_format($p['amount']) ?> RWF</td>
<td class="good"><?= $p['status'] ?></td>
<td><?= $p['payment_date'] ?></td>
</tr>
<?php endwhile; ?>

</table>

</div>

</div>

</body>
</html>