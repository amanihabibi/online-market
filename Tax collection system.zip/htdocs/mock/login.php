<?php
session_start();
include '../connect.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

if(isset($_POST['login'])){
    $tin = $_POST['tin'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM taxpayers WHERE tin=?");
    $stmt->bind_param("s", $tin);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows === 1){
        $user = $result->fetch_assoc();
        if(password_verify($password, $user['password'])){
            // Login success
            $_SESSION['taxpayer_id'] = $user['id'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['tin'] = $user['tin'];
            header("Location:dashboard.php");
            exit;
        } else {
            $error = "Invalid password!";
        }
    } else {
        $error = "TIN not found!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Mock RRA Login</title>
<style>
body { background:#f5f6fa; display:flex; justify-content:center; align-items:center; min-height:100vh; font-family:Arial,sans-serif; }
.login-container { background:#fff; padding:40px 50px; border-radius:12px; box-shadow:0 10px 25px rgba(0,0,0,0.1); width:400px; }
h2 { text-align:center; margin-bottom:25px; color:#2f3640; }
input { width:100%; padding:12px 15px; margin:8px 0 20px 0; border-radius:8px; border:1px solid #dcdde1; font-size:14px; }
input[type="submit"] { background:#40739e; color:#fff; font-weight:bold; border:none; cursor:pointer; transition:.3s; }
input[type="submit"]:hover { background:#273c75; }
.message { text-align:center; margin-bottom:15px; font-size:14px; color:red; }
</style>
</head>
<body>
<div class="login-container">
<h2>Mock RRA Login</h2>
<?php if(isset($error)) echo "<div class='message'>$error</div>"; ?>
<form method="POST" action="">
    <input type="text" name="tin" placeholder="Enter TIN" required>
    <input type="password" name="password" placeholder="Enter Password" required>
    <input type="submit" name="login" value="Login">
</form>
</div>
</body>
</html>