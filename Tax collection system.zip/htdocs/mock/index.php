<?php
session_start();
include '../connect.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

if(isset($_POST['signup'])){

    $full_name = trim($_POST['full_name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $business_type = $_POST['business_type'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if($password !== $confirm_password){
        $error = "Passwords do not match!";
    } else {

        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        $tin = "TIN" . rand(100000, 999999);

        /* CHECK DUPLICATES */
        $stmt = $conn->prepare("SELECT * FROM taxpayers WHERE email=? OR tin=?");
        $stmt->bind_param("ss", $email, $tin);
        $stmt->execute();
        $result = $stmt->get_result();

        if($result->num_rows > 0){
            $error = "Email or TIN already exists!";
        } else {

            /* INSERT TAXPAYER */
            $stmt = $conn->prepare("
                INSERT INTO taxpayers 
                (full_name, tin, phone, email, business_type, registration_date, password)
                VALUES (?, ?, ?, ?, ?, CURDATE(), ?)
            ");

            $stmt->bind_param(
                "ssssss",
                $full_name,
                $tin,
                $phone,
                $email,
                $business_type,
                $password_hash
            );

            $stmt->execute();
            $taxpayer_id = $stmt->insert_id;

            /* TAX AMOUNT BY BUSINESS TYPE */
            $tax = 0;

            switch($business_type){
                case "Retail Shop": $tax = 15000; break;
                case "Restaurant": $tax = 20000; break;
                case "Mobile Money Agent": $tax = 10000; break;
                case "Salon": $tax = 10000; break;
                case "Pharmacy": $tax = 220000; break;
                case "Electronics": $tax = 18000; break;
                default: $tax = 10000;
            }

            /* ==============================
               IMPORTANT FIX: USE ADMIN DATE
            =============================== */

            $admin = $conn->query("
                SELECT next_tax_date 
                FROM businesses 
                ORDER BY id ASC 
                LIMIT 1
            ")->fetch_assoc();

            $next_tax_date = $admin['next_tax_date'];

            if(!$next_tax_date){
                // fallback if admin not set anything
                $next_tax_date = date('Y-m-d', strtotime("+3 months"));
            }

            /* CREATE BUSINESS */
            $business_name = $full_name . "'s " . $business_type;

            $stmt = $conn->prepare("
                INSERT INTO businesses 
                (taxpayer_id, business_name, business_type, tax, next_tax_date)
                VALUES (?, ?, ?, ?, ?)
            ");

            $stmt->bind_param(
                "issis",
                $taxpayer_id,
                $business_name,
                $business_type,
                $tax,
                $next_tax_date
            );

            $stmt->execute();
            $business_id = $stmt->insert_id;

            /* OPTIONAL FIRST TAX RECORD */
            $stmt = $conn->prepare("
                INSERT INTO taxes 
                (business_id, tax_type, tax_amount, due_date, paid)
                VALUES (?, 'Quarterly Tax', ?, ?, 0)
            ");

            $stmt->bind_param("ids", $business_id, $tax, $next_tax_date);
            $stmt->execute();

            /* SESSION */
            $_SESSION['taxpayer_id'] = $taxpayer_id;
            $_SESSION['business_id'] = $business_id;
            $_SESSION['name'] = $full_name;
            $_SESSION['tin'] = $tin;

            header("Location: dashboard.php");
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Mock RRA - Sign Up</title>

<style>
body { font-family: Arial; background:#f4f6f9; }

.container {
    width:400px;
    margin:50px auto;
    background:#fff;
    padding:30px;
    border-radius:10px;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}

h2 { text-align:center; }

input, select {
    width:100%;
    padding:10px;
    margin:10px 0;
    border-radius:5px;
    border:1px solid #ccc;
}

button {
    width:100%;
    padding:10px;
    background:#27ae60;
    color:#fff;
    border:none;
    border-radius:5px;
    cursor:pointer;
}

button:hover { background:#2ecc71; }

.error {
    background:#f8d7da;
    color:#721c24;
    padding:10px;
    border-radius:5px;
    margin-bottom:10px;
}
</style>
</head>

<body>

<div class="container">

<h2>Mock RRA Sign Up</h2>

<?php if(isset($error)) echo "<div class='error'>$error</div>"; ?>

<form method="POST">

Full Name:
<input type="text" name="full_name" required>

Phone:
<input type="text" name="phone">

Email:
<input type="email" name="email" required>

Business Type:
<select name="business_type" required>
    <option value="">Select Business Type</option>
    <option>Retail Shop</option>
    <option>Restaurant</option>
    <option>Mobile Money Agent</option>
    <option>Salon</option>
    <option>Pharmacy</option>
    <option>Electronics</option>
    <option>Other</option>
</select>

Password:
<input type="password" name="password" required>

Confirm Password:
<input type="password" name="confirm_password" required>

<button type="submit" name="signup">Sign Up</button>

<p>I already have account <a href="login.php">Login</a></p>
<p>Tax System <a href="../index.php">Home</a></p>

</form>

</div>

</body>
</html>