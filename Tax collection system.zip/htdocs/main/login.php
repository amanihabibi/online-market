<?php
session_start();
include '../connect.php';

$error = "";

if(isset($_POST['login'])){
    $tin = $_POST['tin'];
    $password = $_POST['password'];

    // Check TIN
    $stmt = $conn->prepare("SELECT * FROM taxpayers WHERE tin=?");
    $stmt->bind_param("s", $tin);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows == 1){
        $user = $result->fetch_assoc();

        // Verify password
        if(password_verify($password, $user['password'])){
            $_SESSION['taxpayer_id'] = $user['id'];
            $_SESSION['tin'] = $user['tin'];
            $_SESSION['name'] = $user['full_name'];

            header("Location: dashboard.php");
            exit;
        } else {
            $error = "Incorrect password!";
        }

    } else {
        $error = "TIN not found!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login - Business Tax System</title>
    <style>
        body {
            font-family: Arial;
            background: linear-gradient(to right, #2980b9, #6dd5fa);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin:0;
        }

        /* System Title */
        .system-title {
            color: #fff;
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 20px;
            text-align: center;
        }

        .login-box {
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            width: 350px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 6px;
            border: 1px solid #ccc;
        }

        button {
            width: 100%;
            padding: 10px;
            background: #27ae60;
            color: #fff;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        button:hover {
            background: #219150;
        }

        .error {
            color: red;
            text-align: center;
        }

        .footer {
            text-align: center;
            margin-top: 10px;
        }

        .footer a {
            text-decoration: none;
            color: #2980b9;
        }
    </style>
</head>
<body>

<!-- System Title -->
<div class="system-title">
    Business Tax Management System
</div>

<div class="login-box">
    <h2>Login</h2>

    <?php if($error) echo "<p class='error'>$error</p>"; ?>

    <form method="POST">
        <input type="text" name="tin" placeholder="Enter TIN" required>
        <input type="password" name="password" placeholder="Enter Password" required>

        <button type="submit" name="login">Login</button>
    </form>

    <div class="footer">
        <p>
            Don't have an account? You must have a TIN number for your business.
            <a href="../mock/index.php">Sign Up</a>
        </p>
    </div>
</div>

</body>
</html>