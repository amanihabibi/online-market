<?php
session_start();
include '../connect.php';

if(!isset($_SESSION['taxpayer_id'])){
    header("Location: login.php");
    exit;
}

$taxpayer_id = $_SESSION['taxpayer_id'];

$message = "";
$error = "";

/* USER */
$stmt = $conn->prepare("SELECT * FROM taxpayers WHERE id=?");
$stmt->bind_param("i", $taxpayer_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

/* BUSINESS */
$stmt2 = $conn->prepare("SELECT * FROM businesses WHERE taxpayer_id=?");
$stmt2->bind_param("i", $taxpayer_id);
$stmt2->execute();
$business = $stmt2->get_result()->fetch_assoc();

/* =========================
   ONLY PASSWORD CHANGE
========================= */
if(isset($_POST['change_password'])){

    $old = $_POST['old_password'];
    $new = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];

    if(empty($old) || empty($new) || empty($confirm)){
        $error = "All password fields are required!";
    }
    elseif(strlen($new) < 6){
        $error = "Password must be at least 6 characters!";
    }
    elseif($new !== $confirm){
        $error = "Passwords do not match!";
    }
    else{

        if(password_verify($old, $user['password'])){

            $hashed = password_hash($new, PASSWORD_DEFAULT);

            $update = $conn->prepare("UPDATE taxpayers SET password=? WHERE id=?");
            $update->bind_param("si", $hashed, $taxpayer_id);
            $update->execute();

            $message = "Password changed successfully!";
        } else {
            $error = "Old password is incorrect!";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Profile | Smart Tax System</title>

<style>
body{
    margin:0;
    font-family:Segoe UI;
    background:#f4f6f9;
}

/* HEADER */
.header{
    background:#111827;
    color:white;
    padding:14px 20px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    position:fixed;
    width:100%;
    top:0;
}

.header h2{
    position:absolute;
    left:50%;
    transform:translateX(-50%);
    margin:0;
    font-size:22px;
    font-weight:800;
}

.header a{
    background:#ef4444;
    color:white;
    padding:8px 14px;
    border-radius:6px;
    text-decoration:none;
}

/* SIDEBAR */
.sidebar{
    width:220px;
    height:100vh;
    background:#1f2937;
    position:fixed;
    top:55px;
    padding-top:20px;
}

.sidebar a{
    display:block;
    padding:12px;
    color:#cbd5e1;
    text-decoration:none;
}

.sidebar a:hover{
    background:#111827;
    color:white;
}

/* MAIN */
.main{
    margin-left:230px;
    padding:90px 20px 40px;
}

/* CARD */
.card{
    background:white;
    padding:20px;
    margin-bottom:15px;
    border-radius:10px;
}

/* INPUT */
input{
    width:100%;
    padding:10px;
    margin:6px 0;
    border:1px solid #ccc;
    border-radius:6px;
    background:#f3f4f6;
}

/* BUTTON */
button{
    padding:10px 15px;
    background:#2563eb;
    color:white;
    border:none;
    border-radius:6px;
    cursor:pointer;
    font-weight:600;
}

/* ALERTS */
.success{
    background:#16a34a;
    color:white;
    padding:10px;
    border-radius:6px;
    margin-bottom:10px;
}

.error{
    background:#dc2626;
    color:white;
    padding:10px;
    border-radius:6px;
    margin-bottom:10px;
}

/* FOOTER */
.footer{
    background:#111827;
    color:#cbd5e1;
    padding:30px;
    margin-left:230px;
}

.footer-container{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:20px;
}

.footer h3{
    color:white;
}
.footer a{
    color:#9ca3af;
    text-decoration:none;
}
</style>
</head>

<body>

<!-- HEADER -->
<div class="header">
    <h2>Personal Profile</h2>
    <a href="logout.php">Logout</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="choose_products.php">🛒 Record Sales</a>
   
    <a href="expenses.php">💸 Supplied Products</a>
    <a href="../mock/login.php">🧾 Pay Quarterly Tax</a>
    <a href="reports.php">📊 Reports</a>
    <a href="profile.php">👤 Profile</a>
</div>

<div class="main">

<?php if($message): ?><div class="success"><?= $message ?></div><?php endif; ?>
<?php if($error): ?><div class="error"><?= $error ?></div><?php endif; ?>

<!-- LOCKED PROFILE -->
<div class="card">
<h3>👤 Profile Information </h3>

<input type="text" value="<?= htmlspecialchars($user['full_name']) ?>" readonly>
<input type="text" value="<?= htmlspecialchars($user['phone']) ?>" readonly>
<input type="text" value="<?= htmlspecialchars($user['email']) ?>" readonly>
<input type="text" value="<?= htmlspecialchars($user['national_id']) ?>" readonly>
<input type="text" value="<?= htmlspecialchars($user['tin']) ?>" readonly>
<input type="text" value="<?= htmlspecialchars($user['business_type']) ?>" readonly>

<p style="color:gray;font-size:13px;">
⚠ Profile details cannot be edited for security reasons.
</p>
</div>

<!-- BUSINESS -->
<div class="card">
<h3>🏢 Business Details</h3>

<?php if($business): ?>
<p><b>Name:</b> <?= $business['business_name'] ?></p>
<p><b>Location:</b> <?= $business['location'] ?></p>
<p><b>Tax:</b> <?= number_format($business['tax']) ?> RWF</p>
<?php endif; ?>

</div>

<!-- PASSWORD ONLY -->
<div class="card">
<h3>🔐 Change Password</h3>

<form method="POST">
<input type="password" name="old_password" placeholder="Old Password" required>
<input type="password" name="new_password" placeholder="New Password" required>
<input type="password" name="confirm_password" placeholder="Confirm Password" required>
<button name="change_password">Update Password</button>
</form>
</div>

</div>

<!-- FOOTER -->
<div class="footer">
    <div class="footer-container">

        <div>
            <h3>Smart Tax System</h3>
            <p>Secure government-style tax management platform.</p>
        </div>

        <div>
            <h3>Links</h3>
            <a href="dashboard.php">Dashboard</a><br>
            <a href="reports.php">Reports</a><br>
            <a href="choose_products.php">Sales</a>
        </div>

        <div>
            <h3>Contact</h3>
            <p>Location: Kigali, Rwanda</p>
            <p>Email: amanihabinshuti91@gmail.com</p>
            <p>Tel: +250 781 205 157</p>
            
        </div>

    </div>
</div>

</body>
</html>