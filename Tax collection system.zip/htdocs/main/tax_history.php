<?php
session_start();
include '../connect.php';

// Protect page
if(!isset($_SESSION['taxpayer_id'])){
    header("Location: login.php");
    exit;
}

$taxpayer_id = $_SESSION['taxpayer_id'];

// Get business info
$business_stmt = $conn->prepare("SELECT * FROM businesses WHERE taxpayer_id=?");
$business_stmt->bind_param("i", $taxpayer_id);
$business_stmt->execute();
$business = $business_stmt->get_result()->fetch_assoc();
$business_id = $business['id'] ?? 0;

// Check if a specific date was clicked
$clicked_date = $_GET['date'] ?? null;

// Get distinct sale dates
$sales_dates_stmt = $conn->prepare("SELECT DISTINCT DATE(sale_date) as sale_day FROM sales WHERE business_id=? ORDER BY sale_day DESC");
$sales_dates_stmt->bind_param("i", $business_id);
$sales_dates_stmt->execute();
$sales_dates = $sales_dates_stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daily Activity History - Smart Tax System</title>
    <style>
        body { font-family: Arial; margin:0; padding:0; background:#f4f6f9; }
        .header { background:#2c3e50; color:#fff; padding:15px 20px; display:flex; justify-content:space-between; align-items:center; }
        .sidebar { width:220px; background:#34495e; height:100vh; position:fixed; top:0; left:0; padding-top:60px; }
        .sidebar a { display:block; color:#ecf0f1; padding:15px 20px; text-decoration:none; }
        .sidebar a:hover { background:#2980b9; }
        .main { margin-left:220px; padding:20px; }
        table { width:100%; border-collapse: collapse; margin-top:20px; }
        th, td { border:1px solid #ccc; padding:10px; text-align:center; }
        th { background:#2980b9; color:#fff; }
        a.date-link { color:#2980b9; text-decoration:none; font-weight:bold; }
        a.date-link:hover { text-decoration:underline; }
        h2 { margin-top:0; }
    </style>
</head>
<body>

<div class="header">
    <h2>Daily Activity History</h2>
    <a href="logout.php" style="color:#fff; background:#e74c3c; padding:8px 15px; border-radius:5px; text-decoration:none;">Logout</a>
</div>

<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="choose_products.php">🛒 Record Sales</a>
    <a href="sales_history.php">📋 Tax History</a>
    <a href="expenses.php">💸 Supplied Produsts</a>
    <a href="../mock/login.php">🧾 Pay Quarterly Tax</a>
    <a href="tax_history.php">📜 Sales History</a>
    <a href="reports.php">📊 Reports</a>
    <a href="profile.php">👤 Profile</a>
</div>

<div class="main">
    <h2>All Daily Activities for <?= htmlspecialchars($business['business_name'] ?? 'Your Business') ?></h2>

    <table>
        <tr>
            <th>Date</th>
            <th>Revenue (RWF)</th>
            <th>Cost (RWF)</th>
            <th>Expenses (RWF)</th>
            <th>Profit (RWF)</th>
            <th>Tax (RWF)</th>
        </tr>
        <?php while($row = $sales_dates->fetch_assoc()): 
            $date = $row['sale_day'];

            // Revenue for this day
            $rev_stmt = $conn->prepare("SELECT SUM(total_price) as total FROM sales WHERE business_id=? AND DATE(sale_date)=?");
            $rev_stmt->bind_param("is", $business_id, $date);
            $rev_stmt->execute();
            $revenue = $rev_stmt->get_result()->fetch_assoc()['total'] ?? 0;

            // Cost for this day
            $cost_stmt = $conn->prepare("SELECT SUM(total_cost) as total FROM sales WHERE business_id=? AND DATE(sale_date)=?");
            $cost_stmt->bind_param("is", $business_id, $date);
            $cost_stmt->execute();
            $cost = $cost_stmt->get_result()->fetch_assoc()['total'] ?? 0;

            // Expenses for this day
            $exp_stmt = $conn->prepare("SELECT SUM(amount) as total FROM expenses WHERE business_id=? AND DATE(created_at)=?");
            $exp_stmt->bind_param("is", $business_id, $date);
            $exp_stmt->execute();
            $expenses = $exp_stmt->get_result()->fetch_assoc()['total'] ?? 0;

            $profit = $revenue - ($cost + $expenses);

            // Tax (5% of profit)
            $tax_amount = $profit * 0.18;
        ?>
        <tr>
            <td><a class="date-link" href="?date=<?= $date ?>"><?= $date ?></a></td>
            <td><?= number_format($revenue) ?></td>
            <td><?= number_format($cost) ?></td>
            <td><?= number_format($expenses) ?></td>
            <td><?= number_format($profit) ?></td>
            <td><?= number_format($tax_amount) ?></td>
        </tr>
        <?php endwhile; ?>
    </table>

    <?php if($clicked_date): 
        // Show detailed products for the clicked date
        $products_stmt = $conn->prepare("
            SELECT p.product_name, s.quantity, s.total_cost, s.total_price 
            FROM sales s 
            JOIN products p ON p.id=s.product_id 
            WHERE s.business_id=? AND DATE(s.sale_date)=?
        ");
        $products_stmt->bind_param("is", $business_id, $clicked_date);
        $products_stmt->execute();
        $products_result = $products_stmt->get_result();
    ?>
        <h3>Products Sold on <?= $clicked_date ?></h3>
        <table>
            <tr>
                <th>Product Name</th>
                <th>Quantity Sold</th>
                <th>Total Cost (RWF)</th>
                <th>Total Price (RWF)</th>
                <th>Profit (RWF)</th>
            </tr>
            <?php while($prod = $products_result->fetch_assoc()): 
                $prod_profit = $prod['total_price'] - $prod['total_cost'];
            ?>
            <tr>
                <td><?= htmlspecialchars($prod['product_name']) ?></td>
                <td><?= $prod['quantity'] ?></td>
                <td><?= number_format($prod['total_cost']) ?></td>
                <td><?= number_format($prod['total_price']) ?></td>
                <td><?= number_format($prod_profit) ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
    <?php endif; ?>

</div>

</body>
</html>