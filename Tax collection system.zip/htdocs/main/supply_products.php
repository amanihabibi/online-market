<?php
session_start();
include '../connect.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

date_default_timezone_set('Africa/Kigali');

if(!isset($_SESSION['taxpayer_id'])){
    header("Location: login.php");
    exit;
}

$taxpayer_id = $_SESSION['taxpayer_id'];

$business = $conn->query("SELECT * FROM businesses WHERE taxpayer_id=$taxpayer_id")->fetch_assoc();
$business_id = $business['id'] ?? 0;
$business_name = $business['business_name'] ?? 'My Business';

$message = "";

/* FAVORITES */
$favorites = $conn->query("
    SELECT p.* 
    FROM products p
    JOIN user_favorites uf ON uf.product_id = p.id
    WHERE uf.business_id = $business_id
    ORDER BY uf.last_sold DESC
");

/* SAVE SUPPLY */
if(isset($_POST['save_supply'])){

    $product_ids = $_POST['product_id'] ?? [];
    $quantities = $_POST['quantity'] ?? [];
    $costs = $_POST['cost_price'] ?? [];

    $saved = false;

    for($i=0; $i<count($product_ids); $i++){

        $pid = intval($product_ids[$i]);
        $qty = intval($quantities[$i]);
        $cost = floatval($costs[$i]);

        if($qty <= 0) continue;

        $check = $conn->query("SELECT * FROM products WHERE id=$pid");
        if($check->num_rows == 0) continue;

        $p = $check->fetch_assoc();
        $product_name = $p['product_name'];
        $old_cost = $p['cost'];

        $total = $qty * $cost;

        if($cost > 0 && $cost != $old_cost){
            $conn->query("UPDATE products SET cost=$cost WHERE id=$pid");
        }

        $supply_date = date('Y-m-d H:i:s');

        $conn->query("
            INSERT INTO supplies (business_id, product_name, quantity, cost_price, total_cost, supply_date)
            VALUES ($business_id, '$product_name', $qty, $cost, $total, '$supply_date')
        ");

        $saved = true;
    }

    $message = $saved ? "✅ Supply recorded successfully" : "⚠ No data saved";
}

/* DATES */
$dates = $conn->query("
    SELECT DATE(supply_date) as sdate, COUNT(*) as total_records
    FROM supplies 
    WHERE business_id=$business_id
    GROUP BY DATE(supply_date)
    ORDER BY sdate DESC
");

$selected_date = $_GET['date'] ?? null;

if($selected_date){
    $stmt = $conn->prepare("
        SELECT product_name, SUM(quantity) as total_qty, cost_price, SUM(total_cost) as total_amount
        FROM supplies 
        WHERE business_id=? AND DATE(supply_date)=?
        GROUP BY product_name, cost_price
    ");
    $stmt->bind_param("is", $business_id, $selected_date);
    $stmt->execute();
    $details = $stmt->get_result();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Supply Management | Smart Tax System</title>

<style>
body{
    font-family:'Segoe UI',sans-serif;
    margin:0;
    background:#f4f6f9;
}

/* HEADER */
.header{
    background:#2c3e50;
    color:#fff;
    padding:12px 20px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    position:fixed;
    width:100%;
    top:0;
    height:55px;
    box-sizing:border-box;
}

/* SIDEBAR */
.sidebar{
    width:230px;
    height:100vh;
    background:#34495e;
    position:fixed;
    top:55px;
    padding-top:20px;
}

.sidebar a{
    display:block;
    color:#ecf0f1;
    padding:14px 20px;
    text-decoration:none;
}

.sidebar a:hover{background:#2c3e50;}
.sidebar a.active{background:#2c3e50;}

/* MAIN */
.main{
    margin-left:240px;
    padding:80px 25px 40px;
}

/* CARD */
.card{
    background:#fff;
    padding:20px;
    border-radius:10px;
    margin-bottom:20px;
    box-shadow:0 3px 10px rgba(0,0,0,0.1);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

th,td{
    padding:12px;
    border:1px solid #eee;
    text-align:center;
}

th{
    background:#2980b9;
    color:white;
}

/* BUTTON */
button{
    padding:10px 20px;
    background:green;
    color:white;
    border:none;
    border-radius:5px;
}

/* DATE LINKS */
.date-link{
    display:block;
    padding:10px;
    background:#ecf0f1;
    margin-bottom:5px;
    border-radius:5px;
    text-decoration:none;
}

/* FOOTER (SAFE + ORIGINAL CONTENT) */
.footer{
    background:#1a252f;
    color:#ecf0f1;
    padding:30px;
    margin-left:240px;
}

.footer-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
    gap:20px;
}

.footer h3{
    color:#1abc9c;
}

.footer-bottom{
    text-align:center;
    margin-top:15px;
    border-top:1px solid #34495e;
    padding-top:10px;
}
</style>
</head>

<body>

<!-- HEADER -->
<div class="header">
    <h2>📦 Supply Products - <?= $business_name ?></h2>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="choose_products.php">🛒 Record Sales</a>
 
    <a href="supply_products.php" class="active">💸 Supply Products</a>
    <a href="../mock/login.php">🧾 Pay Quarterly Tax</a>
    <a href="reports.php">📊 Reports</a>
    <a href="profile.php">👤 Profile</a>
</div>

<div class="main">

<h3>Supply Favorite Products</h3>

<?php if($message) echo "<div class='card'>$message</div>"; ?>

<div class="card">
<form method="POST">

<table>
<tr>
<th>Product</th>
<th>Quantity</th>
<th>Cost Price</th>
</tr>

<?php while($p = $favorites->fetch_assoc()): ?>
<tr>
<td><?= $p['product_name'] ?></td>
<td><input type="number" name="quantity[]" value="0"></td>
<td><input type="number" name="cost_price[]" value="<?= $p['cost'] ?>"></td>
<input type="hidden" name="product_id[]" value="<?= $p['id'] ?>">
</tr>
<?php endwhile; ?>

</table>

<br>
<button name="save_supply">💾 Save Supply</button>

</form>
</div>

<div class="card">
<h3>📅 Supply Dates</h3>

<?php while($d = $dates->fetch_assoc()): ?>
<a class="date-link" href="?date=<?= $d['sdate'] ?>">
    <?= $d['sdate'] ?> (<?= $d['total_records'] ?>)
</a>
<?php endwhile; ?>
</div>

<?php if($selected_date): ?>
<div class="card">
<h3>📜 Report for <?= $selected_date ?></h3>

<table>
<tr>
<th>Product</th>
<th>Qty</th>
<th>Cost</th>
<th>Total</th>
</tr>

<?php
$day_total = 0;
while($row = $details->fetch_assoc()):
$day_total += $row['total_amount'];
?>
<tr>
<td><?= $row['product_name'] ?></td>
<td><?= $row['total_qty'] ?></td>
<td><?= number_format($row['cost_price']) ?></td>
<td><?= number_format($row['total_amount']) ?></td>
</tr>
<?php endwhile; ?>
</table>

</div>
<?php endif; ?>

</div>

<!-- FOOTER (UNCHANGED MEANING) -->
<div class="footer">
    <div class="footer-grid">

        <div>
            <h3>About</h3>
            <p>Smart Tax System helps businesses manage supplies, sales, and tax reporting efficiently.</p>
        </div>

        <div>
            <h3>Links</h3>
            <p>Dashboard<br>Sales<br>Reports<br>Profile</p>
        </div>

        <div>
            <h3>Contact</h3>
            <p>Kigali, Rwanda</p>
            <p>amanihabinshuti91@gmail.com</p>
            <p>+250 781 205 157</p>
        </div>

    </div>

    <div class="footer-bottom">
        © <?= date("Y") ?> Smart Tax System
    </div>
</div>

</body>
</html>