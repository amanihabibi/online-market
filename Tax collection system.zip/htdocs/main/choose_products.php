<?php
session_start();
include '../connect.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

if(!isset($_SESSION['taxpayer_id'])){
    header("Location: login.php");
    exit;
}

$taxpayer_id = $_SESSION['taxpayer_id'];

$user = $conn->query("SELECT * FROM taxpayers WHERE id=$taxpayer_id")->fetch_assoc();
$name = $user['full_name'] ?? '';

$business = $conn->query("SELECT * FROM businesses WHERE taxpayer_id=$taxpayer_id")->fetch_assoc();
$business_id = $business['id'] ?? 0;
$business_name = $business['business_name'] ?? '';

$message = "";
$fav_message = "";

/* FAVORITES */
if(isset($_POST['save_favorites'])){
    $favorites = $_POST['favorite'] ?? [];
    foreach($favorites as $fav_pid){
        $fav_pid = intval($fav_pid);
        $now = date('Y-m-d H:i:s');

        $conn->query("
            INSERT INTO user_favorites (business_id, product_id, last_sold)
            VALUES ($business_id, $fav_pid, '$now')
            ON DUPLICATE KEY UPDATE last_sold='$now'
        ");
    }
    $fav_message = "✅ Favorites updated!";
}

/* SALES */
if(isset($_POST['submit'])){
    $product_ids = $_POST['product_id'] ?? [];
    $quantities  = $_POST['quantity'] ?? [];
    $prices      = $_POST['price'] ?? [];

    $total_revenue = 0;
    $total_cost = 0;

    for($i=0; $i<count($product_ids); $i++){
        $pid = intval($product_ids[$i]);
        $qty = intval($quantities[$i]);
        $new_price = floatval($prices[$i]);

        if($qty <= 0) continue;

        $p = $conn->query("SELECT * FROM products WHERE id=$pid")->fetch_assoc();
        if(!$p) continue;

        $cost = $p['cost'];
        $old_price = $p['selling_price'];

        if($new_price > $old_price){
            $conn->query("UPDATE products SET selling_price=$new_price WHERE id=$pid");
            $old_price = $new_price;
        }

        $price_total = $old_price * $qty;
        $cost_total = $cost * $qty;

        $total_revenue += $price_total;
        $total_cost += $cost_total;

        $conn->query("
            INSERT INTO sales (business_id, product_id, quantity, total_cost, total_price, sale_date)
            VALUES ($business_id, $pid, $qty, $cost_total, $price_total, NOW())
        ");

        $now = date('Y-m-d H:i:s');
        $conn->query("
            INSERT INTO user_favorites (business_id, product_id, last_sold)
            VALUES ($business_id, $pid, '$now')
            ON DUPLICATE KEY UPDATE last_sold='$now'
        ");
    }

    $profit = $total_revenue - $total_cost;
    $tax = $profit * 0.18;

    $message = "✅ Sales recorded | Revenue: ".number_format($total_revenue).
               " | Profit: ".number_format($profit).
               " | Tax: ".number_format($tax);
}

/* PRODUCTS */
$products = $conn->query("
    SELECT p.*, uf.last_sold
    FROM products p
    LEFT JOIN user_favorites uf
    ON uf.product_id = p.id AND uf.business_id = $business_id
    ORDER BY uf.last_sold DESC, p.product_name ASC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Sales Management | Smart Tax System</title>

<style>
body{font-family:'Segoe UI',sans-serif;margin:0;background:#f4f6f9;}

/* HEADER (FIXED SMALL) */
.header{
    background:linear-gradient(90deg,#2c3e50,#1a252f);
    color:#fff;
    padding:10px 20px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    position:fixed;
    width:100%;
    top:0;
    height:55px;
    z-index:1000;
    box-sizing:border-box;
}

.header-left{
    display:flex;
    align-items:center;
    gap:10px;
}

.header-left h2{
    margin:0;
    font-size:16px;
}

.header-left small{
    font-size:12px;
    color:#bdc3c7;
}

/* LOGOUT */
.logout-btn{
    background:#e74c3c;
    color:#fff;
    padding:7px 14px;
    border-radius:20px;
    text-decoration:none;
    font-size:13px;
}
.logout-btn:hover{background:#c0392b;}

/* SIDEBAR */
.sidebar{
    width:230px;
    height:100vh;
    background:#34495e;
    position:fixed;
    top:55px;
    padding-top:20px;
}
.sidebar a{
    display:flex;
    align-items:center;
    gap:10px;
    color:#ecf0f1;
    padding:14px 20px;
    text-decoration:none;
}
.sidebar a:hover{background:#2c3e50;}
.sidebar a.active{background:#2c3e50;}

/* MAIN */
.main{
    margin-left:240px;
    padding:80px 25px 40px;
}

/* SEARCH */
.search-box{margin-bottom:15px;}
.search-box input{
    width:300px;
    padding:10px 15px;
    border-radius:25px;
    border:1px solid #ccc;
}
.search-box input:focus{border-color:#1abc9c;}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
    background:#fff;
}
th,td{
    padding:12px;
    border-bottom:1px solid #eee;
    text-align:center;
}
th{background:#34495e;color:#fff;}

input[type=number]{width:80px;}

/* BUTTONS */
button{
    padding:10px 20px;
    border:none;
    border-radius:5px;
    cursor:pointer;
    margin:10px 5px 10px 0;
}
.save-btn{background:#27ae60;color:white;}
.fav-btn{background:#f39c12;color:white;}

/* SUMMARY */
.summary{
    background:#fff;
    padding:15px;
    margin:10px 0;
    border-left:5px solid #27ae60;
}

/* FOOTER */
.smart-footer{
    background:#1a252f;
    color:#ecf0f1;
    padding:30px 25px 10px;
    margin-left:240px;
}
.footer-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:20px;
}
.footer-col h3{color:#1abc9c;}
.footer-links a{
    display:block;
    color:#bdc3c7;
    text-decoration:none;
    margin:6px 0;
}
.footer-links a:hover{color:#1abc9c;}
.footer-bottom{
    text-align:center;
    margin-top:15px;
    border-top:1px solid #34495e;
    padding-top:10px;
}
</style>
</head>

<body>

<!-- HEADER -->
<div class="header">
    <div class="header-left">
        <span style="font-size:18px;">🛒</span>
        <div>
            <h2>Sales Management</h2>
            <small><?= $name ?> | <?= $business_name ?></small>
        </div>
    </div>

    <a href="logout.php" class="logout-btn" onclick="return confirm('Logout?')">🚪 Logout</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="choose_products.php" class="active">🛒 Record Sales</a>
    
    <a href="supply_products.php">💸 Supplied Products</a>
    <a href="../mock/login.php">🧾 Pay Quarterly Tax</a>
    <a href="reports.php">📊 Reports</a>
    <a href="profile.php">👤 Profile</a>
</div>

<div class="main">

<div class="search-box">
    🔍 <input type="text" id="searchInput" placeholder="Search product..." onkeyup="searchProduct()">
</div>

<?php if($message) echo "<div class='summary'>$message</div>"; ?>
<?php if($fav_message) echo "<div class='summary'>$fav_message</div>"; ?>

<form method="POST">

<button name="submit" class="save-btn">💾 Save Sales</button>
<button name="save_favorites" class="fav-btn">⭐ Save Favorites</button>

<table>
<tr>
<th>Fav</th>
<th>Product</th>
<th>Cost</th>
<th>Price</th>
<th>Qty</th>
<th>Total</th>
</tr>

<?php while($p = $products->fetch_assoc()): ?>
<tr>
<td><input type="checkbox" name="favorite[]" value="<?= $p['id'] ?>" <?= $p['last_sold'] ? "checked":"" ?>></td>
<td><?= $p['product_name'] ?></td>
<td><?= number_format($p['cost']) ?></td>
<td><input type="number" name="price[]" value="<?= $p['selling_price'] ?>"></td>
<td>
<input type="number" name="quantity[]" value="0" oninput="calc(this)">
<input type="hidden" name="product_id[]" value="<?= $p['id'] ?>">
</td>
<td class="row_total">0</td>
</tr>
<?php endwhile; ?>

</table>
</form>

</div>

<!-- FOOTER -->
<div class="smart-footer">
    <div class="footer-grid">

        <div class="footer-col">
            <h3>About</h3>
            <p>Smart Tax System helps manage sales, taxes, and business tracking in real time.</p>
        </div>

        <div class="footer-col footer-links">
            <h3>Quick Links</h3>
            <a href="dashboard.php">Dashboard</a>
            <a href="reports.php">Reports</a>
            <a href="profile.php">Profile</a>
        </div>

        <div class="footer-col">
            <h3>Contact</h3>
            <p>📍 Kigali, Rwanda</p>
            <p>📞 +250 781 205 157</p>
            <p>📧 amanihabinshuti91@gmail.com</p>
        </div>

    </div>

    <div class="footer-bottom">
        © <?= date("Y") ?> Smart Tax System
    </div>
</div>

<script>
function calc(input){
    let row = input.closest('tr');
    let qty = input.value || 0;
    let price = row.querySelector('input[name="price[]"]').value || 0;
    row.querySelector('.row_total').innerText = (qty * price).toLocaleString();
}

function searchProduct(){
    let input = document.getElementById("searchInput").value.toLowerCase();
    let rows = document.querySelectorAll("table tr");

    for(let i=1;i<rows.length;i++){
        let product = rows[i].children[1].innerText.toLowerCase();
        rows[i].style.display = product.includes(input) ? "" : "none";
    }
}
</script>

</body>
</html>