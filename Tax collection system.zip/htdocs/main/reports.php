<?php
session_start();
include '../connect.php';

if(!isset($_SESSION['taxpayer_id'])){
    header("Location: login.php");
    exit;
}

$taxpayer_id = $_SESSION['taxpayer_id'];

$business = $conn->query("
    SELECT * FROM businesses 
    WHERE taxpayer_id=$taxpayer_id
")->fetch_assoc();

$business_id = $business['id'];
$business_name = $business['business_name'];

$dates = $conn->query("
    SELECT DATE(sale_date) AS d FROM sales WHERE business_id=$business_id
    UNION
    SELECT DATE(supply_date) AS d FROM supplies WHERE business_id=$business_id
    ORDER BY d DESC
");

$selected_date = $_GET['date'] ?? null;

/* DAILY DATA */
$revenue = 0;
$sales_cost = 0;
$total_supply = 0;
$profit = 0;

if($selected_date){

    $sales = $conn->query("
        SELECT SUM(total_price) AS revenue,
               SUM(total_cost) AS cost
        FROM sales
        WHERE business_id=$business_id
        AND DATE(sale_date)='$selected_date'
    ")->fetch_assoc();

    $revenue = $sales['revenue'] ?? 0;
    $sales_cost = $sales['cost'] ?? 0;

    $supply = $conn->query("
        SELECT SUM(total_cost) AS total_supply
        FROM supplies
        WHERE business_id=$business_id
        AND DATE(supply_date)='$selected_date'
    ")->fetch_assoc();

    $total_supply = $supply['total_supply'] ?? 0;

    $profit = $revenue - $sales_cost;
}

$sales_tax = $profit * 0.18;
$supply_tax = $total_supply * 0.05;

$capital_used = $sales_cost + $total_supply;
$total_tax = $sales_tax + $supply_tax;

/* SOLD */
$sold_products = null;
if($selected_date){
    $sold_products = $conn->query("
        SELECT p.product_name, s.quantity, s.total_price
        FROM sales s
        JOIN products p ON p.id = s.product_id
        WHERE s.business_id=$business_id
        AND DATE(s.sale_date)='$selected_date'
    ");
}

/* SUPPLY */
$supplied_products = null;
if($selected_date){
    $supplied_products = $conn->query("
        SELECT product_name, quantity, total_cost
        FROM supplies
        WHERE business_id=$business_id
        AND DATE(supply_date)='$selected_date'
    ");
}

/* TREND */
$trend = $conn->query("
    SELECT DATE(sale_date) AS d,
           SUM(total_price) AS revenue,
           SUM(total_cost) AS sales_cost
    FROM sales
    WHERE business_id=$business_id
    GROUP BY DATE(sale_date)
    ORDER BY d ASC
");

$trend_supply = $conn->query("
    SELECT DATE(supply_date) AS d,
           SUM(total_cost) AS supply
    FROM supplies
    WHERE business_id=$business_id
    GROUP BY DATE(supply_date)
");

$supply_map = [];
while($s = $trend_supply->fetch_assoc()){
    $supply_map[$s['d']] = $s['supply'];
}

$days=[];$revenueArr=[];$costArr=[];$profitArr=[];$supplyArr=[];$salesTaxArr=[];$supplyTaxArr=[];

while($r=$trend->fetch_assoc()){
    $d=$r['d'];
    $rev=$r['revenue'] ?? 0;
    $cost=$r['sales_cost'] ?? 0;
    $sup=$supply_map[$d] ?? 0;

    $pro=$rev-$cost;

    $days[]=$d;
    $revenueArr[]=$rev;
    $costArr[]=$cost;
    $profitArr[]=$pro;
    $supplyArr[]=$sup;
    $salesTaxArr[]=$pro*0.18;
    $supplyTaxArr[]=$sup*0.05;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Reports | Smart Tax System</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
body{
    margin:0;
    font-family:'Segoe UI',sans-serif;
    background:#f4f6f9;
}

/* HEADER */
.header{
    background:linear-gradient(90deg,#2c3e50,#1a252f);
    color:white;
    height:55px;
    padding:10px 20px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    position:fixed;
    top:0;
    width:100%;
    box-sizing:border-box;
}

.header h2{
    font-size:16px;
    margin:0;
}

/* SIDEBAR */
.sidebar{
    width:230px;
    height:100vh;
    background:#34495e;
    position:fixed;
    top:55px;
    padding-top:20px;
}

.sidebar a{
    display:block;
    padding:14px 20px;
    color:#ecf0f1;
    text-decoration:none;
}

.sidebar a:hover{background:#2c3e50;}
.sidebar a.active{background:#2c3e50;}

/* MAIN */
.main{
    margin-left:240px;
    padding:80px 25px 40px;
}

/* DATE LIST */
.date-box{
    width:25%;
    float:left;
}

.date{
    display:block;
    padding:10px;
    margin-bottom:5px;
    background:#ecf0f1;
    border-radius:5px;
    text-decoration:none;
    color:#2c3e50;
}

.date:hover{background:#dfe6e9;}

/* CONTENT */
.content{
    width:70%;
    float:right;
}

.card{
    background:white;
    padding:15px;
    margin-bottom:15px;
    border-radius:10px;
    box-shadow:0 2px 8px rgba(0,0,0,0.1);
}

/* GRID */
.grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(140px,1fr));
    gap:10px;
}

.box{
    background:white;
    padding:15px;
    text-align:center;
    border-radius:8px;
    box-shadow:0 2px 5px rgba(0,0,0,0.1);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

th,td{
    padding:10px;
    border:1px solid #ddd;
    text-align:center;
}

th{
    background:#2c3e50;
    color:white;
}

/* FOOTER */
.footer{
    background:#1a252f;
    color:white;
    padding:25px;
    margin-left:240px;
    clear:both;
}

.footer-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
    gap:20px;
}

.footer-bottom{
    text-align:center;
    margin-top:10px;
    border-top:1px solid #34495e;
    padding-top:10px;
}
</style>
</head>

<body>

<!-- HEADER -->
<div class="header">
    <h2>📊 Reports - <?= $business_name ?></h2>
    <a href="logout.php" style="background:red;color:white;padding:7px 12px;border-radius:5px;text-decoration:none;">Logout</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="choose_products.php">🛒 Record Sales</a>
    
    <a href="supply_products.php">💸 Supplied Products</a>
    <a href="../mock/login.php">🧾 Pay Quarterly Tax</a>
    <a href="reports.php" class="active">📊 Reports</a>
    <a href="profile.php">👤 Profile</a>
</div>

<div class="main">

<div class="date-box">
<h3>Dates</h3>
<?php while($d=$dates->fetch_assoc()): ?>
<a class="date" href="?date=<?= $d['d'] ?>"><?= $d['d'] ?></a>
<?php endwhile; ?>
</div>

<div class="content">

<?php if(!$selected_date): ?>
<div class="card">
<h3>Select a date to view report</h3>
</div>

<div class="card">
<canvas id="overviewChart"></canvas>
</div>
<?php endif; ?>

<?php if($selected_date): ?>

<div class="card">
<canvas id="dailyChart"></canvas>
</div>

<div class="grid">
<div class="box">Revenue<br><b><?= number_format($revenue) ?></b></div>
<div class="box">Cost<br><b><?= number_format($sales_cost) ?></b></div>
<div class="box">Supply<br><b><?= number_format($total_supply) ?></b></div>
<div class="box">Profit<br><b><?= number_format($profit) ?></b></div>
<div class="box">Sales Tax<br><b><?= number_format($sales_tax) ?></b></div>
<div class="box">Supply Tax<br><b><?= number_format($supply_tax) ?></b></div>
</div>

<?php endif; ?>

<!-- SOLD -->
<?php if($selected_date): ?>
<div class="card">
<h3>Sold Products</h3>
<table>
<tr><th>Product</th><th>Qty</th><th>Total</th></tr>
<?php while($s=$sold_products->fetch_assoc()): ?>
<tr>
<td><?= $s['product_name'] ?></td>
<td><?= $s['quantity'] ?></td>
<td><?= number_format($s['total_price']) ?></td>
</tr>
<?php endwhile; ?>
</table>
</div>
<?php endif; ?>

<!-- SUPPLY -->
<?php if($selected_date): ?>
<div class="card">
<h3>Supplied Products</h3>
<table>
<tr><th>Product</th><th>Qty</th><th>Total</th></tr>
<?php while($sp=$supplied_products->fetch_assoc()): ?>
<tr>
<td><?= $sp['product_name'] ?></td>
<td><?= $sp['quantity'] ?></td>
<td><?= number_format($sp['total_cost']) ?></td>
</tr>
<?php endwhile; ?>
</table>
</div>
<?php endif; ?>

</div>
</div>

<!-- FOOTER -->
<div class="footer">
    <div class="footer-grid">
        <div>
            <h3>About</h3>
            <p>Smart Tax System helps manage business reports and taxation.</p>
        </div>
        <div>
            <h3>Links</h3>
            
            <p><a href="dashboard.php">Dashboard </a> </p>
             <p>Sales</p>
             <p>Supply</p>
             <p>Reports</p>
        </div>
        <div>
            <h3>Contact</h3>
            <p>Kigali, Rwanda</p>
            <p>Email: amanihabinshuti92@gmail.com</p>
             <p>Tel: +250 781 205 157</p>
           
        </div>
    </div>

    <div class="footer-bottom">
        © <?= date("Y") ?> Smart Tax System
    </div>
</div>

<script>
<?php if(!$selected_date): ?>
new Chart(document.getElementById('overviewChart'), {
    type:'line',
    data:{
        labels:<?= json_encode($days) ?>,
        datasets:[
            {label:'Revenue',data:<?= json_encode($revenueArr) ?>,borderColor:'green',fill:false},
            {label:'Cost',data:<?= json_encode($costArr) ?>,borderColor:'red',fill:false},
            {label:'Supply',data:<?= json_encode($supplyArr) ?>,borderColor:'purple',fill:false},
            {label:'Profit',data:<?= json_encode($profitArr) ?>,borderColor:'blue',fill:false}
        ]
    }
});
<?php else: ?>
new Chart(document.getElementById('dailyChart'), {
    type:'bar',
    data:{
        labels:['Revenue','Cost','Supply','Profit','Sales Tax','Supply Tax'],
        datasets:[{
            data:[
                <?= $revenue ?>,
                <?= $sales_cost ?>,
                <?= $total_supply ?>,
                <?= $profit ?>,
                <?= $sales_tax ?>,
                <?= $supply_tax ?>
            ],
            backgroundColor:['green','red','purple','blue','orange','brown']
        }]
    }
});
<?php endif; ?>
</script>

</body>
</html>