<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include '../connect.php';

if(!isset($_SESSION['taxpayer_id'])){
    header("Location: login.php");
    exit;
}

$taxpayer_id = $_SESSION['taxpayer_id'];

$taxpayer = $conn->query("SELECT * FROM taxpayers WHERE id=$taxpayer_id")->fetch_assoc();
$name = $taxpayer['full_name'];
$tin = $taxpayer['tin'] ?? 'N/A';

$business = $conn->query("SELECT * FROM businesses WHERE taxpayer_id=$taxpayer_id LIMIT 1")->fetch_assoc();
$business_id = $business['id'];

$today = date('Y-m-d');

/* TODAY DATA */
$rev = $conn->query("SELECT SUM(total_price) t FROM sales WHERE business_id=$business_id AND DATE(sale_date)='$today'")->fetch_assoc();
$revenue = $rev['t'] ?? 0;

$cost_q = $conn->query("SELECT SUM(total_cost) t FROM sales WHERE business_id=$business_id AND DATE(sale_date)='$today'")->fetch_assoc();
$cost = $cost_q['t'] ?? 0;

$profit = $revenue - $cost;
$tax = $profit * 0.18;

/* CHART */
$c = $conn->query("
SELECT DATE(sale_date) d,
SUM(total_price-total_cost) p,
SUM((total_price-total_cost)*0.18) t
FROM sales
WHERE business_id=$business_id
GROUP BY DATE(sale_date)
ORDER BY d ASC LIMIT 7
");

$dates=[];$profits=[];$taxes=[];
while($r=$c->fetch_assoc()){
    $dates[]=$r['d'];
    $profits[]=$r['p'];
    $taxes[]=$r['t'];
}

/* BUSINESSES */
$biz = $conn->query("
SELECT 
b.id,
b.business_name,
b.business_type,
b.tax,
b.next_tax_date,

(
    SELECT p.status
    FROM payments p
    WHERE p.business_id = b.id
    AND p.payment_date >= b.next_tax_date
    ORDER BY p.id DESC
    LIMIT 1
) AS payment_status

FROM businesses b
WHERE b.taxpayer_id=$taxpayer_id
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Smart Tax Dashboard</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
body{
    font-family:'Segoe UI',sans-serif;
    margin:0;
    background:#f4f6f9;
}

/* HEADER */
.header{
    background:linear-gradient(90deg,#2c3e50,#1a252f);
    color:#fff;
    padding:15px 25px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    position:fixed;
    width:100%;
    top:0;
    z-index:1000;
}

.header h2{margin:0;font-size:18px;}

/* LOGOUT BUTTON */
.logout-btn{
    background:#e74c3c;
    color:#fff;
    padding:8px 16px;
    border-radius:25px;
    text-decoration:none;
    font-size:14px;
    transition:0.3s;
    display:flex;
    align-items:center;
    gap:5px;
}
.logout-btn:hover{
    background:#c0392b;
    transform:scale(1.05);
}

/* SIDEBAR */
.sidebar{
    width:230px;
    height:100vh;
    background:#34495e;
    position:fixed;
    top:60px;
    padding-top:20px;
}

.sidebar a{
    display:flex;
    align-items:center;
    gap:10px;
    color:#ecf0f1;
    padding:14px 20px;
    text-decoration:none;
    transition:0.3s;
    border-left:4px solid transparent;
}

.sidebar a:hover{
    background:#2c3e50;
    border-left:4px solid #1abc9c;
    padding-left:25px;
}

.sidebar a.active{
    background:#2c3e50;
    border-left:4px solid #1abc9c;
}

/* MAIN */
.main{
    margin-left:240px;
    padding:90px 25px 60px;
}

/* FOOTER */
.smart-footer{
    background:#1a252f;
    color:#ecf0f1;
    padding:30px 25px 10px;
    margin-left:240px;
}

.footer-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:20px;
}

.footer-col h3{
    margin-bottom:10px;
    color:#1abc9c;
}

.footer-col p{
    font-size:14px;
    line-height:1.6;
}

.footer-links a{
    display:block;
    color:#bdc3c7;
    text-decoration:none;
    margin:6px 0;
    font-size:14px;
    transition:0.3s;
}

.footer-links a:hover{
    color:#1abc9c;
    padding-left:5px;
}

.footer-bottom{
    border-top:1px solid #34495e;
    margin-top:20px;
    padding-top:10px;
    text-align:center;
    font-size:13px;
    color:#aaa;
}

/* EXISTING DESIGN */
.tax-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:15px;margin-bottom:25px;}
.tax-card{background:#fff;padding:18px;border-radius:10px;box-shadow:0 3px 10px rgba(0,0,0,0.1);border-left:6px solid #ccc;}
.active{border-left-color:#28a745;}
.overdue{border-left-color:#dc3545;}
.none{border-left-color:#6c757d;}
.countdown{font-weight:bold;margin-top:8px;}

.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:15px;margin-bottom:20px;}
.card{background:#fff;padding:20px;border-radius:10px;text-align:center;box-shadow:0 3px 10px rgba(0,0,0,0.1);}

@keyframes blink{
0%{opacity:1;}
50%{opacity:0.3;}
100%{opacity:1;}
}
</style>
</head>

<body>

<!-- HEADER -->
<div class="header">
    <h2>👋 Welcome <?= $name ?> | TIN: <?= $tin ?></h2>
    <a href="logout.php" class="logout-btn" onclick="return confirmLogout()">🚪 Logout</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="dashboard.php" class="active">🏠 Dashboard</a>
    <a href="choose_products.php">🛒 Record Sales</a>
   
    <a href="supply_products.php">💸 Supplied Products</a>
    <a href="../mock/login.php">🧾 Pay Quarterly Tax</a>
    <a href="reports.php">📊 Reports</a>
    <a href="profile.php">👤 Profile</a>
</div>

<div class="main">

<h2>⏳ Tax Deadlines</h2>

<div class="tax-grid">
<?php
$i=0;
while($b=$biz->fetch_assoc()):
$i++;

$next = $b['next_tax_date'];
$payment_status = $b['payment_status'];

if($payment_status == 'paid'){
    $class = "active";
    $status = "✅ PAID";
    $target = null;
}
elseif(!$next){
    $class = "none";
    $status = "No Schedule";
    $target = null;
}
elseif($next < $today){
    $class = "overdue";
    $status = "⚠️ Overdue";
    $target = null;
}
else{
    $class = "active";
    $status = "Active";
    $target = $next." 23:59:59";
}
?>
<div class="tax-card <?= $class ?>">
<h3><?= $b['business_name'] ?></h3>
<p>Type: <?= $b['business_type'] ?></p>
<p>Tax: <?= number_format($b['tax']) ?> RWF</p>
<p>Status: <?= $status ?></p>
<div id="cd<?= $i ?>" class="countdown"></div>

<script>
<?php if($target): ?>
let t<?= $i ?> = new Date("<?= $target ?>").getTime();
setInterval(()=>{
let d=t<?= $i ?>-new Date().getTime();
let box=document.getElementById("cd<?= $i ?>");
if(d<0){box.innerHTML="⚠️ EXPIRED";box.style.color="red";}
else{
let days=Math.floor(d/(1000*60*60*24));
let h=Math.floor((d%(1000*60*60*24))/(1000*60*60));
let m=Math.floor((d%(1000*60*60))/(1000*60));
let s=Math.floor((d%(1000*60))/1000);
box.innerHTML=days+"d "+h+"h "+m+"m "+s+"s";
}
},1000);
<?php else: ?>
document.getElementById("cd<?= $i ?>").innerHTML="N/A";
<?php endif; ?>
</script>
</div>
<?php endwhile; ?>
</div>

<h2>📊 Today Overview</h2>
<div class="cards">
<div class="card"><h4>Revenue</h4><?= number_format($revenue) ?></div>
<div class="card"><h4>Cost</h4><?= number_format($cost) ?></div>
<div class="card"><h4>Profit</h4><?= number_format($profit) ?></div>
<div class="card"><h4>Tax</h4><?= number_format($tax) ?></div>
</div>

<h2>📈 Profit & Tax</h2>
<canvas id="chart"></canvas>

<script>
new Chart(document.getElementById('chart'),{
type:'line',
data:{
labels:<?= json_encode($dates) ?>,
datasets:[
{label:'Profit',data:<?= json_encode($profits) ?>,borderColor:'green'},
{label:'Tax',data:<?= json_encode($taxes) ?>,borderColor:'orange'}
]
}
});

/* LOGOUT CONFIRM */
function confirmLogout(){
    return confirm("Are you sure you want to logout?");
}
</script>

</div>

<div class="smart-footer">

    <div class="footer-grid">

        <!-- ABOUT -->
        <div class="footer-col">
            <h3>About</h3>
            <p>
                Smart Tax System helps businesses manage sales, calculate tax,
                and track deadlines easily. Built for efficiency, accuracy,
                and real-time monitoring.
            </p>
        </div>

        <!-- QUICK LINKS -->
        <div class="footer-col footer-links">
            <h3>Quick Links</h3>
            <a href="dashboard.php">Dashboard</a>
            <a href="choose_products.php">Record Sales</a>
            <a href="sales_history.php">Tax History</a>
            <a href="reports.php">Reports</a>
            <a href="profile.php">Profile</a>
        </div>

        <!-- CONTACT -->
        <div class="footer-col">
            <h3>Contact</h3>
            <p>📍 Kigali, Rwanda</p>
            <p>📞 +250 781 205 157</p>
            <p>📧 amanihabinshuti91@gmail.com</p>
        </div>

    </div>

    <div class="footer-bottom">
        © <?= date("Y") ?> Smart Tax System | All Rights Reserved
    </div>

</div>

</body>
</html>