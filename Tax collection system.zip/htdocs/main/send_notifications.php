<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../connect.php';

// Today and 3 days ahead
$today = date('Y-m-d');
$next3days = date('Y-m-d', strtotime('+3 days'));

// Get all unpaid taxes due within the next 3 days
$stmt = $conn->prepare("
    SELECT t.*, b.business_name, tp.full_name, tp.email
    FROM scheduled_taxes t
    JOIN businesses b ON t.business_id = b.id
    JOIN taxpayers tp ON b.taxpayer_id = tp.id
    WHERE t.paid = 0 AND t.due_date BETWEEN ? AND ?
");
$stmt->bind_param("ss", $today, $next3days);
$stmt->execute();
$result = $stmt->get_result();

while($row = $result->fetch_assoc()) {
    $to = $row['email'];
    $subject = "Upcoming Tax Payment Reminder";
    $business = $row['business_name'];
    $name = $row['full_name'];
    $tax_amount = number_format($row['tax_amount']);
    $due_date = $row['due_date'];

    $message = "
    <html>
    <head>
        <title>Tax Payment Reminder</title>
    </head>
    <body>
        <p>Dear $name,</p>
        <p>This is a friendly reminder that your business <strong>$business</strong> has a scheduled tax payment of <strong>$tax_amount RWF</strong>.</p>
        <p><strong>Due Date:</strong> $due_date</p>
        <p>Please ensure payment before the deadline to avoid penalties.</p>
        <p>Thank you,<br>Smart Tax System</p>
    </body>
    </html>
    ";

    // To send HTML mail, set Content-type header
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: noreply@yourdomain.com" . "\r\n";

    // Send email
    if(mail($to, $subject, $message, $headers)) {
        echo "Notification sent to $name ($to) <br>";
    } else {
        echo "Failed to send to $name ($to) <br>";
    }
}
?>